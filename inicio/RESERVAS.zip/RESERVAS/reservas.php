<?php
// Serve reservations to the admin dashboard via AJAX while keeping direct navigation within admin.php.
$isAjax = isset($_GET['ajax']) && $_GET['ajax'] === '1';

if (!$isAjax) {
    $redirectParams = $_GET;
    unset($redirectParams['ajax']);
    $queryString = http_build_query($redirectParams);
    $targetUrl = '../admin.php' . ($queryString ? '?' . $queryString : '') . '#reservas';
    header('Location: ' . $targetUrl);
    exit;
}

$reservas = [];
$error = null;
$data = [];

$token = $_GET['token'] ?? ($_COOKIE['userToken'] ?? null);

if (!$token) {
    $error = 'No se encontró el token de sesión. Inicia sesión nuevamente.';
} else {
    $baseUrl = 'http://turistas.spring.informaticapp.com:2410/api/v1/reservas';
    $query = [];

    if (!empty($_GET['estado'])) {
        $query['estado'] = $_GET['estado'];
    }
    if (!empty($_GET['busqueda'])) {
        $query['busqueda'] = $_GET['busqueda'];
    }
    if (!empty($_GET['empresaId'])) {
        $query['empresaId'] = $_GET['empresaId'];
    }
    if (isset($_GET['page']) && is_numeric($_GET['page'])) {
        $query['page'] = (int) $_GET['page'];
    }
    if (isset($_GET['size']) && is_numeric($_GET['size'])) {
        $query['size'] = (int) $_GET['size'];
    }

    $requestUrl = $baseUrl . (empty($query) ? '' : '?' . http_build_query($query));

    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => $requestUrl,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . $token
        ],
    ]);

    $response = curl_exec($curl);
    $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $curlError = curl_error($curl);
    curl_close($curl);

    if ($curlError) {
        $error = 'Error de conexión: ' . $curlError;
    } elseif ($httpCode !== 200) {
        $errorData = json_decode($response, true);
        $errorMessage = 'Error HTTP: ' . $httpCode;
        if (isset($errorData['message'])) {
            $errorMessage .= ' - ' . $errorData['message'];
        } elseif (isset($errorData['error'])) {
            $errorMessage .= ' - ' . $errorData['error'];
        } elseif (!empty($response)) {
            $errorMessage .= ' - ' . substr($response, 0, 200);
        }
        $error = $errorMessage;
        error_log('Reservas API error: ' . $errorMessage);
    } else {
        $data = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            $error = 'Error al decodificar JSON: ' . json_last_error_msg();
        } else {
            if (isset($data['data']) && is_array($data['data'])) {
                $reservas = $data['data'];
            } elseif (isset($data['content']) && is_array($data['content'])) {
                $reservas = $data['content'];
            } elseif (isset($data['reservas']) && is_array($data['reservas'])) {
                $reservas = $data['reservas'];
            } elseif (isset($data['items']) && is_array($data['items'])) {
                $reservas = $data['items'];
            } elseif (isset($data['results']) && is_array($data['results'])) {
                $reservas = $data['results'];
            } elseif (is_array($data) && !empty($data)) {
                $reservas = isset($data[0]) ? $data : [$data];
            }
        }
    }
}

if (isset($_GET['debug']) && $_GET['debug'] === '1') {
    header('Content-Type: text/plain; charset=utf-8');
    echo "Total de reservas: " . count($reservas) . "\n\n";
    if (!empty($reservas)) {
        echo "Primera reserva:\n";
        print_r($reservas[0]);
    }
    echo "\nRespuesta completa:\n";
    print_r($data);
    exit;
}

ob_start();
include __DIR__ . '/reservas_table.php';
$content = ob_get_clean();

header('Content-Type: text/html; charset=utf-8');
echo $content;
exit;
?>
                <span>Clientes</span>
            </a>
            <a href="#" class="sidebar-link active">
                <i class="fas fa-suitcase-rolling"></i>
                <span>Reservas</span>
            </a>
        </nav>
    </aside>

    <main class="admin-main-content" id="mainContent">
        <header class="admin-header">
            <div class="header-left">
                <button class="sidebar-toggle" id="sidebarToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <h1 class="page-title">Reservas</h1>
            </div>
            <div class="header-right">
                <div class="user-profile">
                    <div class="profile-info">
                        <img src="https://via.placeholder.com/45" alt="Usuario" class="profile-image">
                        <div class="user-info">
                            <span class="user-name">Administrador</span>
                            <span class="user-role">Admin</span>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <div class="admin-content">
            <?php include __DIR__ . '/reservas_table.php'; ?>
        </div>
    </main>

    <div id="alertasContainer"></div>

    <script>
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        const mainContent = document.getElementById('mainContent');

        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', function() {
                sidebar.classList.toggle('sidebar-collapsed');
                mainContent.classList.toggle('content-expanded');
            });
        }

        document.addEventListener('click', function(event) {
            if (window.innerWidth <= 1024) {
                if (!sidebar.contains(event.target) && !sidebarToggle.contains(event.target)) {
                    sidebar.classList.remove('sidebar-collapsed');
                    mainContent.classList.remove('content-expanded');
                }
            }
        });

        function mostrarAlerta(tipo, mensaje, duracion = 5000) {
            let alertasContainer = document.getElementById('alertasContainer');

            if (!alertasContainer) {
                alertasContainer = document.createElement('div');
                alertasContainer.id = 'alertasContainer';
                document.body.appendChild(alertasContainer);
            }

            const alerta = document.createElement('div');
            alerta.className = `alerta alerta-${tipo}`;

            const iconos = {
                success: '<i class="fas fa-check-circle"></i>',
                error: '<i class="fas fa-exclamation-circle"></i>',
                warning: '<i class="fas fa-exclamation-triangle"></i>',
                info: '<i class="fas fa-info-circle"></i>'
            };

            alerta.innerHTML = `
                <div style="display:flex;align-items:center;gap:10px;">
                    ${iconos[tipo] || ''}
                    <span>${mensaje}</span>
                </div>
                <button class="cerrar-alerta" onclick="this.parentElement.remove()">
                    <i class="fas fa-times"></i>
                </button>
            `;

            alertasContainer.appendChild(alerta);

            setTimeout(() => {
                alerta.style.opacity = '1';
                alerta.style.transform = 'translateY(0)';
            }, 10);

            setTimeout(() => {
                alerta.style.opacity = '0';
                alerta.style.transform = 'translateY(-100%)';
                setTimeout(() => {
                    if (alerta.parentNode) {
                        alerta.remove();
                    }
                }, 300);
            }, duracion);
        }

        window.mostrarAlerta = mostrarAlerta;

        <?php if ($success): ?>
            mostrarAlerta('success', '<?php echo addslashes($success); ?>');
        <?php endif; ?>
    </script>
</body>
</html>
