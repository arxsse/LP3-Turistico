<?php
$apiBase = 'http://turistas.spring.informaticapp.com:2410/api/v1';

$rawToken = $_POST['token'] ?? $_GET['token'] ?? ($_COOKIE['userToken'] ?? null);
$tokenHeader = $rawToken ? 'Bearer ' . $rawToken : null;

$idEmpresa = null;
foreach (['idEmpresa', 'empresaId'] as $empresaKey) {
    if ($idEmpresa !== null) {
        break;
    }
    if (isset($_POST[$empresaKey])) {
        $idEmpresa = (int) $_POST[$empresaKey];
    } elseif (isset($_GET[$empresaKey])) {
        $idEmpresa = (int) $_GET[$empresaKey];
    }
}

$error = null;
$success = null;
$clientes = [];
$servicios = [];
$paquetes = [];
$personal = [];
$personalSeleccionados = [];
$fechaHoy = date('Y-m-d');

function fetchApiCollection(string $url, ?string $tokenHeader): array
{
    if (!$tokenHeader) {
        return ['success' => false, 'data' => [], 'message' => 'Token no disponible'];
    }

    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        CURLOPT_HTTPHEADER => [
            'Authorization: ' . $tokenHeader,
            'Content-Type: application/json'
        ],
    ]);

    $response = curl_exec($curl);
    $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $curlError = curl_error($curl);
    curl_close($curl);

    if ($curlError) {
        return ['success' => false, 'data' => [], 'message' => 'Error de conexión: ' . $curlError];
    }

    if ($httpCode !== 200) {
        return ['success' => false, 'data' => [], 'message' => 'HTTP ' . $httpCode];
    }

    $data = json_decode($response, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        return ['success' => false, 'data' => [], 'message' => 'JSON inválido'];
    }

    if (isset($data['data']) && is_array($data['data'])) {
        return ['success' => true, 'data' => $data['data'], 'message' => null];
    }
    if (isset($data['content']) && is_array($data['content'])) {
        return ['success' => true, 'data' => $data['content'], 'message' => null];
    }
    if (isset($data['items']) && is_array($data['items'])) {
        return ['success' => true, 'data' => $data['items'], 'message' => null];
    }
    if (is_array($data)) {
        return ['success' => true, 'data' => $data, 'message' => null];
    }

    return ['success' => true, 'data' => [], 'message' => null];
}

function buildItemsPayload(string $itemsJson): array
{
    $itemsRaw = json_decode($itemsJson, true);

    if (json_last_error() !== JSON_ERROR_NONE || !is_array($itemsRaw)) {
        throw new InvalidArgumentException('El formato de los ítems no es válido.');
    }

    if (empty($itemsRaw)) {
        throw new InvalidArgumentException('Debes agregar al menos un ítem a la reserva.');
    }

    $payloadItems = [];

    foreach ($itemsRaw as $index => $rawItem) {
        if (!is_array($rawItem)) {
            throw new InvalidArgumentException('El ítem #' . ($index + 1) . ' no es válido.');
        }

        $tipoItem = strtoupper((string) ($rawItem['tipoItem'] ?? ''));

        if (!in_array($tipoItem, ['SERVICIO', 'PAQUETE'], true)) {
            throw new InvalidArgumentException('El ítem #' . ($index + 1) . ' tiene un tipo inválido.');
        }

        $cantidad = (int) ($rawItem['cantidad'] ?? 0);

        if ($cantidad <= 0) {
            throw new InvalidArgumentException('El ítem #' . ($index + 1) . ' debe tener una cantidad mayor a cero.');
        }

        $precioUnitario = (float) ($rawItem['precioUnitario'] ?? 0);

        if ($precioUnitario < 0) {
            throw new InvalidArgumentException('El ítem #' . ($index + 1) . ' tiene un precio unitario inválido.');
        }

        $precioTotal = (float) ($rawItem['precioTotal'] ?? ($cantidad * $precioUnitario));

        if ($precioTotal < 0) {
            throw new InvalidArgumentException('El ítem #' . ($index + 1) . ' tiene un subtotal inválido.');
        }

        $servicioId = null;
        $paqueteId = null;

        if ($tipoItem === 'SERVICIO') {
            $servicioId = isset($rawItem['servicioId']) ? (int) $rawItem['servicioId'] : null;

            if (!$servicioId) {
                throw new InvalidArgumentException('Selecciona un servicio válido en el ítem #' . ($index + 1) . '.');
            }
        } else {
            $paqueteId = isset($rawItem['paqueteId']) ? (int) $rawItem['paqueteId'] : null;

            if (!$paqueteId) {
                throw new InvalidArgumentException('Selecciona un paquete válido en el ítem #' . ($index + 1) . '.');
            }
        }

        $descripcionExtra = isset($rawItem['descripcionExtra']) ? trim((string) $rawItem['descripcionExtra']) : null;

        if ($descripcionExtra === '') {
            $descripcionExtra = null;
        }

        $payloadItems[] = array_filter([
            'tipoItem' => $tipoItem,
            'servicioId' => $servicioId,
            'paqueteId' => $paqueteId,
            'cantidad' => $cantidad,
            'precioUnitario' => $precioUnitario,
            'precioTotal' => $precioTotal,
            'descripcionExtra' => $descripcionExtra,
        ], static function ($value) {
            return $value !== null;
        });
    }

    return $payloadItems;
}

function buildAssignmentsPayload(?string $assignacionesJson, string $fechaServicio): array
{
    if ($assignacionesJson === null || $assignacionesJson === '') {
        return [];
    }

    $assignmentsRaw = json_decode($assignacionesJson, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new InvalidArgumentException('El formato del personal asignado no es válido.');
    }

    if (!is_array($assignmentsRaw)) {
        return [];
    }

    $payload = [];

    foreach ($assignmentsRaw as $index => $rawAssignment) {
        if (!is_array($rawAssignment)) {
            throw new InvalidArgumentException('El personal seleccionado no es válido.');
        }

        $idPersonal = isset($rawAssignment['idPersonal']) ? (int) $rawAssignment['idPersonal'] : null;
        if (!$idPersonal) {
            throw new InvalidArgumentException('Selecciona personal válido.');
        }

        $assignment = [
            'idPersonal' => $idPersonal,
        ];

        if (isset($rawAssignment['idAsignacion']) && (int) $rawAssignment['idAsignacion'] > 0) {
            $assignment['idAsignacion'] = (int) $rawAssignment['idAsignacion'];
        }

        $observaciones = isset($rawAssignment['observaciones']) ? trim((string) $rawAssignment['observaciones']) : null;
        if ($observaciones !== null && $observaciones !== '') {
            $assignment['observaciones'] = $observaciones;
        }

        $fecha = isset($rawAssignment['fechaAsignacion']) ? trim((string) $rawAssignment['fechaAsignacion']) : '';
        if ($fecha === '') {
            $fecha = $fechaServicio;
        }
        $assignment['fechaAsignacion'] = $fecha;

        $payload[] = $assignment;
    }

    return $payload;
}

$personalSeleccionados = [];
if (isset($_POST['asignaciones_json'])) {
    $rawAsignaciones = json_decode((string) $_POST['asignaciones_json'], true);
    if (json_last_error() === JSON_ERROR_NONE && is_array($rawAsignaciones)) {
        foreach ($rawAsignaciones as $rawAsignacion) {
            if (isset($rawAsignacion['idPersonal'])) {
                $personalSeleccionados[] = (int) $rawAsignacion['idPersonal'];
            }
        }
        $personalSeleccionados = array_values(array_unique(array_filter($personalSeleccionados, static fn($id) => $id > 0)));
    }
}

$formContent = function () use (&$error, &$success, &$idEmpresa, &$clientes, &$servicios, &$paquetes, &$personal, &$personalSeleccionados, $apiBase, $fechaHoy) {
        $servicioOptions = array_values(array_filter(array_map(static function ($servicio) {
            $id = $servicio['idServicio'] ?? ($servicio['id'] ?? null);
            if (!$id) {
                return null;
            }

            $nombre = $servicio['nombreServicio'] ?? ($servicio['nombre'] ?? ('Servicio #' . $id));
            $precio = 0.0;
            if (isset($servicio['precioBase'])) {
                $precio = (float) $servicio['precioBase'];
            } elseif (isset($servicio['precio'])) {
                $precio = (float) $servicio['precio'];
            } elseif (isset($servicio['costo'])) {
                $precio = (float) $servicio['costo'];
            }

            return [
                'id' => (int) $id,
                'nombre' => $nombre,
                'precio' => round($precio, 2),
            ];
        }, $servicios), static function ($item) {
            return $item !== null;
        }));

        $paqueteOptions = array_values(array_filter(array_map(static function ($paquete) {
            $id = $paquete['idPaqueteTuristico'] ?? ($paquete['idPaquete'] ?? ($paquete['id'] ?? null));
            if (!$id) {
                return null;
            }

            $nombre = $paquete['nombrePaquete'] ?? ($paquete['nombre'] ?? ('Paquete #' . $id));
            $precio = 0.0;
            if (isset($paquete['precioTotal'])) {
                $precio = (float) $paquete['precioTotal'];
            } elseif (isset($paquete['precioFinal'])) {
                $precio = (float) $paquete['precioFinal'];
            } elseif (isset($paquete['precio'])) {
                $precio = (float) $paquete['precio'];
            }

            return [
                'id' => (int) $id,
                'nombre' => $nombre,
                'precio' => round($precio, 2),
            ];
        }, $paquetes), static function ($item) {
            return $item !== null;
        }));
        ?>
        <div class="content-header">
            <div class="card">
                <div class="card-header">
                    <h2 class="section-title">Crear Nueva Reserva</h2>
                    <div class="header-actions">
                        <button type="button" class="btn btn-secondary" onclick="loadReservasContent()">
                            <i class="fas fa-arrow-left"></i>
                            Volver
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <?php if ($error): ?>
                        <div class="alerta alerta-error" style="margin-bottom: 20px;">
                            <i class="fas fa-exclamation-triangle"></i>
                            <?php echo htmlspecialchars($error); ?>
                        </div>
                    <?php elseif ($success): ?>
                        <div class="alerta alerta-success" style="margin-bottom: 20px;">
                            <i class="fas fa-check-circle"></i>
                            <?php echo htmlspecialchars($success); ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="" class="form-container" id="formNuevaReserva" autocomplete="off">
                        <input type="hidden" name="ajax" value="1">
                        <input type="hidden" name="idEmpresa" value="<?php echo htmlspecialchars($idEmpresa ?? ''); ?>">
                        <input type="hidden" name="idUsuario" id="idUsuarioHidden" value="<?php echo htmlspecialchars($_POST['idUsuario'] ?? ''); ?>">
                        <input type="hidden" name="items_json" id="itemsJsonField" value="<?php echo htmlspecialchars($_POST['items_json'] ?? '[]', ENT_NOQUOTES, 'UTF-8'); ?>">
                        <input type="hidden" name="asignaciones_json" id="asignacionesJsonField" value="<?php echo htmlspecialchars($_POST['asignaciones_json'] ?? '[]', ENT_NOQUOTES, 'UTF-8'); ?>">

                        <section class="form-section">
                            <h3 class="section-subtitle">
                                <i class="fas fa-user-circle"></i>
                                Información principal
                            </h3>
                            <div class="form-grid">
                                <div class="form-group">
                                    <label class="form-label" for="clienteId">Cliente <span class="required">*</span></label>
                                    <select id="clienteId" name="clienteId" class="form-input" required>
                                        <option value="">Selecciona un cliente</option>
                                        <?php foreach ($clientes as $cliente):
                                            $clienteId = $cliente['id'] ?? ($cliente['idCliente'] ?? null);
                                            if (!$clienteId) {
                                                continue;
                                            }
                                            $nombre = $cliente['nombre'] ?? ($cliente['nombres'] ?? '');
                                            $apellido = $cliente['apellido'] ?? ($cliente['apellidos'] ?? '');
                                            $fullName = trim($nombre . ' ' . $apellido);
                                            if ($fullName === '') {
                                                $fullName = $cliente['nombreCompleto'] ?? ('Cliente #' . $clienteId);
                                            }
                                            ?>
                                            <option value="<?php echo htmlspecialchars($clienteId); ?>" <?php echo (isset($_POST['clienteId']) && (int) $_POST['clienteId'] === (int) $clienteId) ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($fullName); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label class="form-label" for="fechaReserva">Fecha de Reserva <span class="required">*</span></label>
                                    <input type="date" id="fechaReserva" name="fechaReserva" class="form-input" value="<?php echo htmlspecialchars($_POST['fechaReserva'] ?? $fechaHoy); ?>" required>
                                </div>

                                <div class="form-group">
                                    <label class="form-label" for="fechaServicio">Fecha del Servicio <span class="required">*</span></label>
                                    <input type="date" id="fechaServicio" name="fechaServicio" class="form-input" value="<?php echo htmlspecialchars($_POST['fechaServicio'] ?? ''); ?>" required>
                                </div>

                                <div class="form-group">
                                    <label class="form-label" for="numeroPersonas">Número de Personas <span class="required">*</span></label>
                                    <input type="number" id="numeroPersonas" name="numeroPersonas" class="form-input" min="1" value="<?php echo htmlspecialchars($_POST['numeroPersonas'] ?? ''); ?>" placeholder="Se calcula automáticamente según los ítems" required>
                                    <small class="form-hint">Se actualiza según las cantidades, pero puedes ajustarlo si necesitas.</small>
                                </div>


                                <div class="form-group">
                                    <label class="form-label" for="descuentoAplicado">Descuento aplicado (S/.)</label>
                                    <input type="number" step="0.01" min="0" id="descuentoAplicado" name="descuentoAplicado" class="form-input" value="<?php echo htmlspecialchars($_POST['descuentoAplicado'] ?? '0'); ?>">
                                    <small class="form-hint">Ingresa 0 si no aplica descuento.</small>
                                </div>

                                <div class="form-group full-width">
                                    <label class="form-label" for="observaciones">Observaciones</label>
                                    <textarea id="observaciones" name="observaciones" class="form-input" rows="3" placeholder="Notas adicionales o instrucciones para el equipo."><?php echo htmlspecialchars($_POST['observaciones'] ?? ''); ?></textarea>
                                </div>
                            </div>
                        </section>

                        <section class="form-section" id="personalSection">
                            <div class="section-header">
                                <h3 class="section-subtitle">
                                    <i class="fas fa-user-friends"></i>
                                    Personal asignado
                                </h3>
                                <div class="section-actions">
                                    <button type="button" class="btn btn-outline" id="personalReloadButton">
                                        <i class="fas fa-sync-alt"></i>
                                        Actualizar catálogo
                                    </button>
                                </div>
                            </div>

                            <p class="form-hint">Selecciona al equipo que acompañará el servicio. Puedes agregar notas para cada integrante.</p>

                            <div class="personal-container" style="display: flex; gap: 20px; flex-wrap: wrap; align-items: stretch;">
                                <div class="personal-column" style="flex: 1 1 320px; background: #fff; border: 1px solid #e0e0e0; border-radius: 12px; padding: 16px; display: flex; flex-direction: column; gap: 16px;">
                                    <div class="personal-column-header" style="display: flex; flex-direction: column; gap: 12px;">
                                        <h4 class="personal-column-title" style="margin: 0; font-size: 16px; font-weight: 600; color: #374151;">Disponibles</h4>
                                        <div class="personal-search-wrapper" style="position: relative;">
                                            <i class="fas fa-search" style="position: absolute; top: 50%; left: 12px; transform: translateY(-50%); color: #9ca3af;"></i>
                                            <input type="search" id="personalSearchInput" class="form-input" placeholder="Buscar por nombre o cargo" style="padding-left: 40px;">
                                        </div>
                                    </div>
                                    <div class="personal-list" id="personalCatalogList" style="flex: 1; overflow-y: auto; display: grid; gap: 12px; max-height: 320px;"></div>
                                </div>

                                <div class="personal-column" style="flex: 1 1 320px; background: #fff; border: 1px solid #e0e0e0; border-radius: 12px; padding: 16px; display: flex; flex-direction: column; gap: 16px;">
                                    <div class="personal-column-header" style="display: flex; align-items: center; justify-content: space-between;">
                                        <h4 class="personal-column-title" style="margin: 0; font-size: 16px; font-weight: 600; color: #374151;">Seleccionados</h4>
                                        <span id="personalSelectedCounter" style="font-size: 13px; color: #6b7280;">0</span>
                                    </div>
                                    <div class="personal-selected-list" id="personalSelectedList" style="flex: 1; display: grid; gap: 12px; overflow-y: auto; max-height: 320px;"></div>
                                    <div class="personal-selected-empty" id="personalSelectedEmpty" style="text-align: center; color: #6b7280; display: flex; flex-direction: column; gap: 8px; align-items: center; justify-content: center; padding: 24px 12px; border: 1px dashed #d1d5db; border-radius: 10px;">
                                        <i class="fas fa-user-plus" style="font-size: 24px;"></i>
                                        <p style="margin: 0;">Aún no has seleccionado personal.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="personal-feedback" id="personalLoader" role="status" style="display: none; align-items: center; gap: 8px; color: #2563eb; margin-top: 16px;">
                                <i class="fas fa-spinner fa-spin"></i>
                                <span>Cargando catálogo de personal…</span>
                            </div>
                            <div class="alerta alerta-error" id="personalError" style="display: none;"></div>
                        </section>

                        <section class="form-section">
                            <div class="section-header">
                                <h3 class="section-subtitle">
                                    <i class="fas fa-layer-group"></i>
                                    Ítems de reserva
                                </h3>
                                <div class="section-actions">
                                    <button type="button" class="btn btn-outline" data-add-item="SERVICIO">
                                        <i class="fas fa-plus-circle"></i>
                                        Agregar servicio
                                    </button>
                                    <button type="button" class="btn btn-outline" data-add-item="PAQUETE">
                                        <i class="fas fa-box"></i>
                                        Agregar paquete
                                    </button>
                                </div>
                            </div>

                            <div class="items-table-wrapper">
                                <table class="items-table" id="itemsTable">
                                    <thead>
                                        <tr>
                                            <th style="width: 110px;">Tipo</th>
                                            <th>Detalle</th>
                                            <th style="width: 110px;">Cantidad</th>
                                            <th style="width: 150px;">Precio unitario</th>
                                            <th style="width: 150px;">Subtotal</th>
                                            <th>Notas</th>
                                            <th style="width: 70px;">Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                                <div class="items-empty" id="itemsEmptyState">
                                    <i class="fas fa-cart-plus"></i>
                                    <p>Agrega servicios o paquetes para construir la reserva.</p>
                                </div>
                            </div>
                        </section>

                        <section class="form-section">
                            <div class="totales-card">
                                <div>
                                    <span class="totales-label">Subtotal estimado</span>
                                    <strong class="totales-value">S/ <span id="subtotalDisplay">0.00</span></strong>
                                </div>
                                <div>
                                    <span class="totales-label">Descuento</span>
                                    <strong class="totales-value">S/ <span id="descuentoDisplay">0.00</span></strong>
                                </div>
                                <div>
                                    <span class="totales-label">Total</span>
                                    <strong class="totales-value">S/ <span id="totalDisplay">0.00</span></strong>
                                </div>
                            </div>
                        </section>

                        <div class="form-actions">
                            <button type="submit" name="crear" class="btn btn-primary">
                                <i class="fas fa-save"></i>
                                Guardar Reserva
                            </button>
                            <button type="button" class="btn btn-secondary" onclick="loadReservasContent()">
                                <i class="fas fa-times"></i>
                                Cancelar
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <script>
            (function() {
                const dataContext = {
                    servicios: <?php echo json_encode($servicioOptions, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>,
                    paquetes: <?php echo json_encode($paqueteOptions, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>,
                    personalPreselected: <?php echo json_encode($personalSeleccionados, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>,
                    apiBase: <?php echo isset($apiBase)
                        ? json_encode((string) $apiBase, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
                        : json_encode('', JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>
                };

                const form = document.getElementById('formNuevaReserva');
                const itemsTableBody = document.querySelector('#itemsTable tbody');
                const itemsEmptyState = document.getElementById('itemsEmptyState');
                const itemsJsonField = document.getElementById('itemsJsonField');
                const asignacionesJsonField = document.getElementById('asignacionesJsonField');
                const empresaInput = form.querySelector('input[name="idEmpresa"]');
                const descuentoInput = document.getElementById('descuentoAplicado');
                const subtotalDisplay = document.getElementById('subtotalDisplay');
                const descuentoDisplay = document.getElementById('descuentoDisplay');
                const totalDisplay = document.getElementById('totalDisplay');
                const personasInput = document.getElementById('numeroPersonas');
                const fechaReservaInput = document.getElementById('fechaReserva');
                const fechaServicioInput = document.getElementById('fechaServicio');
                const addButtons = document.querySelectorAll('[data-add-item]');
                const personalCatalogList = document.getElementById('personalCatalogList');
                const personalSelectedList = document.getElementById('personalSelectedList');
                const personalSelectedEmpty = document.getElementById('personalSelectedEmpty');
                const personalSelectedCounter = document.getElementById('personalSelectedCounter');
                const personalSearchInput = document.getElementById('personalSearchInput');
                const personalLoader = document.getElementById('personalLoader');
                const personalError = document.getElementById('personalError');
                const personalReloadButton = document.getElementById('personalReloadButton');

                const userDataStr = sessionStorage.getItem('userData') || localStorage.getItem('userData');
                let token = null;
                let idEmpresa = form.querySelector('input[name="idEmpresa"]').value || null;
                let userId = null;

                let personalCatalog = [];
                let personalFilter = '';

                const state = {
                    items: [],
                    personalAsignado: []
                };

                if (userDataStr) {
                    try {
                        const userData = JSON.parse(userDataStr);
                        token = userData.token || null;
                        if (!idEmpresa && userData.empresaId) {
                            idEmpresa = userData.empresaId;
                        }
                        if (!idEmpresa && userData.empresa && typeof userData.empresa === 'object') {
                            idEmpresa = userData.empresa.id || userData.empresa.empresaId || idEmpresa;
                        }
                        if (!idEmpresa && userData.tenant && typeof userData.tenant === 'object') {
                            idEmpresa = userData.tenant.idEmpresa || userData.tenant.empresaId || idEmpresa;
                        }
                        userId = userData.id || userData.userId || userData.idUsuario || userData.usuarioId || null;
                        if (!userId && typeof userData.user === 'object' && userData.user !== null) {
                            userId = userData.user.id || userData.user.userId || null;
                        }
                    } catch (error) {
                        console.error('No se pudo leer la sesión del usuario:', error);
                    }
                }

                if (empresaInput && idEmpresa) {
                    empresaInput.value = idEmpresa;
                }

                if (userId) {
                    const hiddenUserInput = document.getElementById('idUsuarioHidden');
                    if (hiddenUserInput) {
                        hiddenUserInput.value = userId;
                    }
                }

                if (fechaReservaInput && fechaServicioInput) {
                    const updateMinFechaServicio = () => {
                        if (fechaServicioInput.value && fechaServicioInput.value < fechaReservaInput.value) {
                            fechaServicioInput.value = fechaReservaInput.value;
                        }
                        fechaServicioInput.min = fechaReservaInput.value;
                    };
                    fechaReservaInput.addEventListener('change', updateMinFechaServicio);
                    updateMinFechaServicio();
                }

                if (personasInput) {
                    personasInput.addEventListener('input', () => {
                        personasInput.dataset.manual = 'true';
                    });
                }

                const sanitizeNumber = (value, fallback = 0) => {
                    const parsed = parseFloat(value);
                    return Number.isFinite(parsed) ? parsed : fallback;
                };

                const normalizeText = (value) => (value ?? '').toString().trim().toLowerCase();

                const collectMessages = (input) => {
                    const messages = [];
                    const visit = (value) => {
                        if (value === null || value === undefined) {
                            return;
                        }
                        if (Array.isArray(value)) {
                            value.forEach((item) => visit(item));
                            return;
                        }
                        if (typeof value === 'object') {
                            Object.values(value).forEach((item) => visit(item));
                            return;
                        }
                        const text = String(value).trim();
                        if (text) {
                            messages.push(text);
                        }
                    };
                    visit(input);
                    return messages;
                };

                const formatApiError = (payload, fallback) => {
                    const messages = [];
                    if (payload && typeof payload.message === 'string') {
                        const trimmed = payload.message.trim();
                        if (trimmed) {
                            messages.push(trimmed);
                        }
                    }
                    collectMessages(payload && payload.details).forEach((msg) => messages.push(msg));
                    collectMessages(payload && payload.errors).forEach((msg) => messages.push(msg));

                    if (!messages.length && typeof fallback === 'string') {
                        const trimmedFallback = fallback.trim();
                        if (trimmedFallback) {
                            messages.push(trimmedFallback);
                        }
                    }

                    if (!messages.length) {
                        messages.push('Ocurrió un error desconocido.');
                    }

                    return messages.join('\n');
                };

                const parseErrorResponse = async (response) => {
                    const statusLabel = ['Error HTTP', response.status || 0, response.statusText || '']
                        .join(' ')
                        .replace(/\s+/g, ' ')
                        .trim();

                    try {
                        const rawText = await response.text();
                        console.error('❌ Error HTTP completo:', rawText);
                        try {
                            const payload = rawText ? JSON.parse(rawText) : {};
                            return {
                                message: formatApiError(payload, statusLabel),
                                payload
                            };
                        } catch (parseError) {
                            const truncated = rawText ? rawText.substring(0, 300) : '';
                            return {
                                message: truncated ? `${statusLabel}: ${truncated}` : statusLabel,
                                payload: null
                            };
                        }
                    } catch (error) {
                        console.error('❌ No se pudo leer el cuerpo de error:', error);
                        return {
                            message: statusLabel,
                            payload: null
                        };
                    }
                };

                const syncAsignacionesField = () => {
                    if (!asignacionesJsonField) {
                        return;
                    }

                    const payload = state.personalAsignado
                        .filter((assignment) => Number.isFinite(Number(assignment.idPersonal)) && Number(assignment.idPersonal) > 0)
                        .map((assignment) => {
                            const normalized = {
                                idPersonal: Number(assignment.idPersonal)
                            };
                            if (assignment.idAsignacion) {
                                normalized.idAsignacion = Number(assignment.idAsignacion);
                            }
                            if (assignment.observaciones && assignment.observaciones.trim() !== '') {
                                normalized.observaciones = assignment.observaciones.trim();
                            }
                            if (assignment.fechaAsignacion) {
                                normalized.fechaAsignacion = assignment.fechaAsignacion;
                            }
                            return normalized;
                        });

                    asignacionesJsonField.value = JSON.stringify(payload);
                };

                const enrichAssignmentsWithCatalog = () => {
                    if (!personalCatalog.length) {
                        return;
                    }
                    const catalogMap = new Map(personalCatalog.map((item) => [item.id, item]));
                    state.personalAsignado = state.personalAsignado.map((assignment) => {
                        const info = catalogMap.get(Number(assignment.idPersonal));
                        if (info) {
                            assignment.nombre = info.nombre;
                            assignment.cargo = info.cargo;
                            assignment.activo = info.activo;
                            assignment.telefono = info.telefono;
                        }
                        return assignment;
                    });
                };

                const removePersonalAssignment = (idPersonal) => {
                    state.personalAsignado = state.personalAsignado.filter((assignment) => Number(assignment.idPersonal) !== Number(idPersonal));
                    renderSelectedPersonal();
                    renderPersonalCatalog();
                };

                const renderSelectedPersonal = () => {
                    if (!personalSelectedList || !personalSelectedEmpty) {
                        return;
                    }

                    personalSelectedList.innerHTML = '';

                    if (!state.personalAsignado.length) {
                        personalSelectedList.style.display = 'none';
                        personalSelectedEmpty.style.display = 'flex';
                        if (personalSelectedCounter) {
                            personalSelectedCounter.textContent = '0';
                        }
                        syncAsignacionesField();
                        return;
                    }

                    personalSelectedList.style.display = 'grid';
                    personalSelectedEmpty.style.display = 'none';

                    state.personalAsignado.forEach((assignment) => {
                        const card = document.createElement('div');
                        card.style.cssText = 'border:1px solid #d1d5db; border-radius:10px; padding:14px; display:flex; flex-direction:column; gap:10px; background:#f9fafb;';

                        const titleRow = document.createElement('div');
                        titleRow.style.cssText = 'display:flex; justify-content:space-between; align-items:flex-start; gap:12px;';

                        const titleContent = document.createElement('div');
                        titleContent.innerHTML = `
                            <div style="font-weight:600; color:#111827;">${assignment.nombre || `Personal #${assignment.idPersonal}`}</div>
                            <div style="font-size:13px; color:#6b7280;">${assignment.cargo || 'Sin cargo asignado'}</div>
                        `;

                        const removeBtn = document.createElement('button');
                        removeBtn.type = 'button';
                        removeBtn.className = 'btn-icon personal-remove';
                        removeBtn.setAttribute('aria-label', 'Quitar personal');
                        removeBtn.innerHTML = '<i class="fas fa-times"></i>';
                        removeBtn.addEventListener('click', () => removePersonalAssignment(assignment.idPersonal));

                        titleRow.appendChild(titleContent);
                        titleRow.appendChild(removeBtn);

                        const obsLabel = document.createElement('label');
                        obsLabel.style.cssText = 'display:flex; flex-direction:column; gap:6px; font-size:13px; color:#4b5563;';
                        obsLabel.textContent = 'Observaciones';

                        const obsTextarea = document.createElement('textarea');
                        obsTextarea.className = 'form-input personal-observaciones';
                        obsTextarea.rows = 2;
                        obsTextarea.placeholder = 'Notas opcionales';
                        obsTextarea.value = assignment.observaciones || '';
                        obsTextarea.addEventListener('input', (event) => {
                            assignment.observaciones = event.target.value;
                            syncAsignacionesField();
                        });

                        obsLabel.appendChild(obsTextarea);

                        card.appendChild(titleRow);
                        card.appendChild(obsLabel);

                        personalSelectedList.appendChild(card);
                    });

                    if (personalSelectedCounter) {
                        personalSelectedCounter.textContent = String(state.personalAsignado.length);
                    }

                    syncAsignacionesField();
                };

                const addPersonalAssignment = (personal) => {
                    if (!personal || !Number(personal.id)) {
                        return;
                    }
                    const alreadySelected = state.personalAsignado.some((assignment) => Number(assignment.idPersonal) === Number(personal.id));
                    if (alreadySelected) {
                        return;
                    }

                    state.personalAsignado.push({
                        idPersonal: Number(personal.id),
                        idAsignacion: personal.idAsignacion ? Number(personal.idAsignacion) : null,
                        observaciones: '',
                        fechaAsignacion: null,
                        nombre: personal.nombre,
                        cargo: personal.cargo,
                        activo: personal.activo,
                        telefono: personal.telefono ?? null
                    });

                    renderSelectedPersonal();
                    renderPersonalCatalog();
                };

                const renderPersonalCatalog = () => {
                    if (!personalCatalogList) {
                        return;
                    }

                    personalCatalogList.innerHTML = '';

                    if (!personalCatalog.length) {
                        if (personalLoader && personalLoader.style.display !== 'none') {
                            return;
                        }
                        const emptyEl = document.createElement('div');
                        emptyEl.style.cssText = 'text-align:center; color:#6b7280; font-size:13px; padding:12px;';
                        emptyEl.textContent = 'No hay personal disponible para mostrar.';
                        personalCatalogList.appendChild(emptyEl);
                        return;
                    }

                    const selectedIds = new Set(state.personalAsignado.map((assignment) => Number(assignment.idPersonal)));
                    const filter = normalizeText(personalFilter);

                    const filtered = personalCatalog.filter((item) => {
                        if (!item || !Number(item.id)) {
                            return false;
                        }
                        if (selectedIds.has(Number(item.id))) {
                            return false;
                        }
                        if (!filter) {
                            return true;
                        }
                        return normalizeText(item.nombre).includes(filter) || normalizeText(item.cargo).includes(filter);
                    });

                    if (!filtered.length) {
                        const emptyEl = document.createElement('div');
                        emptyEl.style.cssText = 'text-align:center; color:#6b7280; font-size:13px; padding:12px;';
                        emptyEl.textContent = filter ? 'No se encontraron coincidencias.' : 'No hay personal disponible para mostrar.';
                        personalCatalogList.appendChild(emptyEl);
                        return;
                    }

                    filtered.slice(0, 60).forEach((item) => {
                        const button = document.createElement('button');
                        button.type = 'button';
                        button.className = 'btn btn-outline personal-catalog-item';
                        button.style.cssText = 'text-align:left; border-color:#d1d5db; display:flex; flex-direction:column; gap:6px;';
                        button.innerHTML = `
                            <span style="font-weight:600; color:#111827;">${item.nombre}</span>
                            <span style="font-size:13px; color:#6b7280;">${item.cargo || 'Sin cargo'}</span>
                            ${item.telefono ? `<span style="font-size:12px; color:#9ca3af;">${item.telefono}</span>` : ''}
                        `;
                        button.addEventListener('click', () => addPersonalAssignment(item));
                        personalCatalogList.appendChild(button);
                    });
                };

                const normalizePersonal = (raw) => {
                    if (!raw || typeof raw !== 'object') {
                        return null;
                    }
                    const id = Number(raw.idPersonal ?? raw.id ?? raw.personalId ?? 0);
                    if (!id) {
                        return null;
                    }

                    let nombre = '';
                    if (raw.nombreCompleto) {
                        nombre = String(raw.nombreCompleto);
                    } else {
                        const partes = [raw.nombres ?? raw.nombre ?? '', raw.apellidos ?? raw.apellido ?? '']
                            .map((part) => (part ?? '').toString().trim())
                            .filter((part) => part !== '');
                        if (partes.length) {
                            nombre = partes.join(' ');
                        }
                    }
                    if (!nombre && raw.usuario && typeof raw.usuario === 'object') {
                        nombre = raw.usuario.nombreCompleto ?? raw.usuario.nombre ?? '';
                    }
                    if (!nombre) {
                        nombre = `Personal #${id}`;
                    }

                    let cargo = '';
                    if (raw.cargo) {
                        if (typeof raw.cargo === 'object' && raw.cargo !== null) {
                            cargo = raw.cargo.nombre ?? raw.cargo.descripcion ?? '';
                        } else {
                            cargo = String(raw.cargo);
                        }
                    }
                    if (!cargo && raw.rol) {
                        cargo = typeof raw.rol === 'object' && raw.rol !== null ? (raw.rol.nombre ?? '') : String(raw.rol);
                    }
                    if (!cargo) {
                        cargo = 'Sin cargo';
                    }

                    const telefono = raw.telefono ?? raw.celular ?? raw.telefonoContacto ?? null;
                    const activo = raw.estado === undefined ? true : Boolean(Number(raw.estado));

                    return {
                        id,
                        nombre,
                        cargo,
                        telefono,
                        activo
                    };
                };

                const loadPersonalCatalog = async () => {
                    if (!personalCatalogList || !personalLoader) {
                        return;
                    }

                    if (!token || !idEmpresa) {
                        if (personalError) {
                            personalError.style.display = 'block';
                            personalError.textContent = 'No se pudo cargar el personal porque falta el token o la empresa.';
                        }
                        if (typeof mostrarAlerta === 'function') {
                            mostrarAlerta('error', 'No se pudo cargar el personal porque falta el token o la empresa.');
                        }
                        return;
                    }

                    try {
                        if (personalError) {
                            personalError.style.display = 'none';
                        }
                        personalLoader.style.display = 'flex';

                        const params = new URLSearchParams({
                            empresaId: idEmpresa,
                            estado: 'true',
                            size: '1000'
                        });

                        const response = await fetch(`${dataContext.apiBase}/personal?${params.toString()}`, {
                            method: 'GET',
                            headers: {
                                'Authorization': `Bearer ${token}`,
                                'Content-Type': 'application/json'
                            }
                        });

                        if (!response.ok) {
                            const errorText = await response.text();
                            throw new Error(errorText || `HTTP ${response.status}`);
                        }

                        const payload = await response.json();

                        let collection = [];
                        if (payload && Array.isArray(payload.data)) {
                            collection = payload.data;
                        } else if (payload && Array.isArray(payload.content)) {
                            collection = payload.content;
                        } else if (payload && Array.isArray(payload.items)) {
                            collection = payload.items;
                        } else if (Array.isArray(payload)) {
                            collection = payload;
                        }

                        personalCatalog = collection.map((item) => normalizePersonal(item)).filter(Boolean);
                        enrichAssignmentsWithCatalog();
                        renderSelectedPersonal();
                        renderPersonalCatalog();
                    } catch (error) {
                        console.error('Error al cargar personal:', error);
                        if (personalError) {
                            personalError.style.display = 'block';
                            personalError.textContent = `No se pudo cargar el personal: ${error.message}`;
                        }
                        if (typeof mostrarAlerta === 'function') {
                            mostrarAlerta('error', `No se pudo cargar el personal: ${error.message}`);
                        }
                    } finally {
                        if (personalLoader) {
                            personalLoader.style.display = 'none';
                        }
                    }
                };

                if (personalSearchInput) {
                    personalSearchInput.addEventListener('input', (event) => {
                        personalFilter = event.target.value;
                        renderPersonalCatalog();
                    });
                }

                if (personalReloadButton) {
                    personalReloadButton.addEventListener('click', () => {
                        loadPersonalCatalog();
                    });
                }

                const initializeAssignments = () => {
                    let rawAssignments = [];

                    if (asignacionesJsonField && asignacionesJsonField.value) {
                        try {
                            const parsed = JSON.parse(asignacionesJsonField.value);
                            rawAssignments = Array.isArray(parsed) ? parsed : [];
                        } catch (error) {
                            rawAssignments = [];
                        }
                    }

                    if (!rawAssignments.length && Array.isArray(dataContext.personalPreselected) && dataContext.personalPreselected.length) {
                        rawAssignments = dataContext.personalPreselected.map((id) => ({ idPersonal: id }));
                    }

                    if (rawAssignments.length) {
                        state.personalAsignado = rawAssignments
                            .map((raw) => {
                                const idPersonal = Number(raw.idPersonal ?? raw.personalId ?? 0);
                                if (!idPersonal) {
                                    return null;
                                }
                                return {
                                    idPersonal,
                                    idAsignacion: raw.idAsignacion ? Number(raw.idAsignacion) : null,
                                    observaciones: raw.observaciones ? String(raw.observaciones) : '',
                                    fechaAsignacion: raw.fechaAsignacion ? String(raw.fechaAsignacion) : null,
                                    nombre: raw.nombre ? String(raw.nombre) : null,
                                    cargo: raw.cargo ? String(raw.cargo) : null
                                };
                            })
                            .filter(Boolean);
                    }

                    renderSelectedPersonal();
                    syncAsignacionesField();
                };

                initializeAssignments();
                loadPersonalCatalog();

                const getCatalog = (tipo) => tipo === 'PAQUETE' ? dataContext.paquetes : dataContext.servicios;

                const findCatalogItem = (tipo, id) => {
                    const list = getCatalog(tipo);
                    return list.find((item) => Number(item.id) === Number(id)) || null;
                };

                const createEmptyItem = (tipo) => {
                    const normalizedTipo = (tipo || 'SERVICIO').toUpperCase();
                    return {
                        tipoItem: normalizedTipo,
                        servicioId: null,
                        paqueteId: null,
                        cantidad: 1,
                        precioUnitario: 0,
                        precioTotal: 0,
                        descripcionExtra: ''
                    };
                };

                const updateResumen = () => {
                    let subtotal = 0;
                    let totalPersonas = 0;

                    state.items = state.items.map((item) => {
                        const cantidad = sanitizeNumber(item.cantidad, 0);
                        const precioUnitario = sanitizeNumber(item.precioUnitario, 0);
                        const precioTotal = sanitizeNumber(item.precioTotal, cantidad * precioUnitario);

                        subtotal += precioTotal;
                        totalPersonas += cantidad;

                        return {
                            ...item,
                            cantidad,
                            precioUnitario,
                            precioTotal
                        };
                    });

                    itemsJsonField.value = JSON.stringify(state.items);

                    subtotalDisplay.textContent = subtotal.toFixed(2);

                    const descuento = Math.max(sanitizeNumber(descuentoInput.value, 0), 0);
                    descuentoDisplay.textContent = descuento.toFixed(2);

                    const total = Math.max(subtotal - descuento, 0);
                    totalDisplay.textContent = total.toFixed(2);

                    if (personasInput && personasInput.dataset.manual !== 'true') {
                        personasInput.value = totalPersonas > 0 ? totalPersonas : '';
                    }

                    if (itemsEmptyState) {
                        itemsEmptyState.style.display = state.items.length ? 'none' : 'flex';
                    }
                };

                const buildSelectOptions = (list, placeholder, blockedIds = new Set(), currentValue = '') => {
                    const fragment = document.createDocumentFragment();
                    const option = document.createElement('option');
                    option.value = '';
                    option.textContent = placeholder;
                    fragment.appendChild(option);

                    list.forEach((item) => {
                        if (!item || item.id === undefined || item.id === null) {
                            return;
                        }
                        const optionValue = String(item.id);
                        const opt = document.createElement('option');
                        opt.value = optionValue;
                        opt.textContent = item.nombre;
                        if (item.precio > 0) {
                            opt.dataset.precio = item.precio;
                        }
                        if (blockedIds.has(optionValue) && optionValue !== currentValue) {
                            opt.disabled = true;
                        }
                        fragment.appendChild(opt);
                    });

                    return fragment;
                };

                const collectSelectedIds = (tipo, excludeIndex = null) => {
                    const targetType = (tipo || 'SERVICIO').toString().toUpperCase();
                    const field = targetType === 'PAQUETE' ? 'paqueteId' : 'servicioId';
                    const collected = new Set();

                    state.items.forEach((entry, idx) => {
                        if (excludeIndex !== null && idx === excludeIndex) {
                            return;
                        }
                        if (!entry || (entry.tipoItem || '').toString().toUpperCase() !== targetType) {
                            return;
                        }
                        const value = entry[field];
                        if (value === null || value === undefined || value === '') {
                            return;
                        }
                        collected.add(String(value));
                    });

                    return collected;
                };

                const hasDuplicateSelections = () => {
                    const servicios = new Set();
                    const paquetes = new Set();

                    for (const item of state.items) {
                        if (!item) {
                            continue;
                        }
                        const tipo = (item.tipoItem || 'SERVICIO').toString().toUpperCase();
                        const field = tipo === 'PAQUETE' ? 'paqueteId' : 'servicioId';
                        const value = item[field];
                        if (value === null || value === undefined || value === '') {
                            continue;
                        }
                        const key = String(value);
                        const registry = tipo === 'PAQUETE' ? paquetes : servicios;
                        if (registry.has(key)) {
                            return true;
                        }
                        registry.add(key);
                    }

                    return false;
                };

                const canAddAnotherItem = (tipo) => {
                    const catalog = getCatalog(tipo);
                    if (!Array.isArray(catalog) || !catalog.length) {
                        return false;
                    }
                    const blocked = collectSelectedIds(tipo);
                    return catalog.some((entry) => entry && entry.id !== undefined && entry.id !== null && !blocked.has(String(entry.id)));
                };

                const renderItems = () => {
                    itemsTableBody.innerHTML = '';

                    state.items.forEach((item, index) => {
                        const row = document.createElement('tr');
                        row.dataset.index = index;

                        const itemTipo = (item.tipoItem || 'SERVICIO').toString().toUpperCase() === 'PAQUETE' ? 'PAQUETE' : 'SERVICIO';
                        state.items[index].tipoItem = itemTipo;

                        const catalog = getCatalog(itemTipo);
                        const referenciaField = itemTipo === 'PAQUETE' ? 'paqueteId' : 'servicioId';
                        const selectPlaceholder = itemTipo === 'PAQUETE' ? 'Selecciona un paquete' : 'Selecciona un servicio';

                        row.innerHTML = `
                            <td>
                                <span class="chip chip-${itemTipo.toLowerCase()}">
                                    <i class="fas ${itemTipo === 'PAQUETE' ? 'fa-box' : 'fa-suitcase-rolling'}"></i>
                                    ${itemTipo === 'PAQUETE' ? 'Paquete' : 'Servicio'}
                                </span>
                            </td>
                            <td>
                                <select class="form-input item-referencia" data-field="${referenciaField}"></select>
                            </td>
                            <td>
                                <input type="number" min="1" step="1" class="form-input item-cantidad" value="${item.cantidad}">
                            </td>
                            <td>
                                <input type="number" min="0" step="0.01" class="form-input item-precio-unitario" value="${Number(item.precioUnitario).toFixed(2)}">
                            </td>
                            <td>
                                <input type="number" min="0" step="0.01" class="form-input item-precio-total" value="${Number(item.precioTotal).toFixed(2)}">
                            </td>
                            <td>
                                <input type="text" class="form-input item-descripcion" value="${item.descripcionExtra || ''}" placeholder="Notas breves">
                            </td>
                            <td class="items-actions">
                                <button type="button" class="btn-icon" data-remove-item>
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        `;

                        itemsTableBody.appendChild(row);

                        const selectElement = row.querySelector('.item-referencia');
                        const currentId = item[referenciaField] ?? '';
                        const currentValue = currentId ? String(currentId) : '';
                        const blockedIds = collectSelectedIds(itemTipo, index);
                        selectElement.appendChild(buildSelectOptions(catalog, selectPlaceholder, blockedIds, currentValue));
                        selectElement.value = currentValue;

                        selectElement.addEventListener('change', (event) => {
                            const selectedId = event.target.value;
                            const duplicates = collectSelectedIds(itemTipo, index);
                            if (selectedId && selectedId !== currentValue && duplicates.has(String(selectedId))) {
                                const message = itemTipo === 'PAQUETE'
                                    ? 'Este paquete ya fue agregado. Ajusta la cantidad si necesitas más.'
                                    : 'Este servicio ya fue agregado. Ajusta la cantidad si necesitas más personas.';
                                if (typeof mostrarAlerta === 'function') {
                                    mostrarAlerta('warning', message);
                                } else {
                                    alert(message);
                                }
                                event.target.value = currentValue;
                                return;
                            }

                            state.items[index][referenciaField] = selectedId ? Number(selectedId) : null;
                            if (referenciaField === 'paqueteId') {
                                state.items[index].servicioId = null;
                            } else {
                                state.items[index].paqueteId = null;
                            }

                            if (selectedId) {
                                const selectedCatalogItem = findCatalogItem(itemTipo, selectedId);
                                if (selectedCatalogItem) {
                                    state.items[index].precioUnitario = selectedCatalogItem.precio;
                                    state.items[index].precioTotal = selectedCatalogItem.precio * sanitizeNumber(state.items[index].cantidad, 1);
                                }
                            }

                            updateResumen();
                            renderItems();
                        });

                        const cantidadInput = row.querySelector('.item-cantidad');
                        if (cantidadInput) {
                            cantidadInput.addEventListener('input', (event) => {
                                const value = Math.max(1, Math.floor(sanitizeNumber(event.target.value, 1)));
                                state.items[index].cantidad = value;
                                state.items[index].precioTotal = value * sanitizeNumber(state.items[index].precioUnitario, 0);
                                renderItems();
                            });
                        }

                        const unitarioInput = row.querySelector('.item-precio-unitario');
                        if (unitarioInput) {
                            unitarioInput.addEventListener('input', (event) => {
                                const value = Math.max(0, sanitizeNumber(event.target.value, 0));
                                state.items[index].precioUnitario = value;
                                state.items[index].precioTotal = value * sanitizeNumber(state.items[index].cantidad, 0);
                                renderItems();
                            });
                        }

                        const totalInput = row.querySelector('.item-precio-total');
                        if (totalInput) {
                            totalInput.addEventListener('input', (event) => {
                                const value = Math.max(0, sanitizeNumber(event.target.value, 0));
                                state.items[index].precioTotal = value;
                                renderItems();
                            });
                        }

                        const descripcionInput = row.querySelector('.item-descripcion');
                        if (descripcionInput) {
                            descripcionInput.addEventListener('input', (event) => {
                                state.items[index].descripcionExtra = event.target.value;
                            });
                        }

                        const removeButton = row.querySelector('[data-remove-item]');
                        if (removeButton) {
                            removeButton.addEventListener('click', () => {
                                state.items.splice(index, 1);
                                renderItems();
                            });
                        }
                    });

                    updateResumen();
                };

                addButtons.forEach((button) => {
                    button.addEventListener('click', () => {
                        const tipo = (button.getAttribute('data-add-item') || 'SERVICIO').toUpperCase();
                        if (!canAddAnotherItem(tipo)) {
                            const label = tipo === 'PAQUETE' ? 'paquetes' : 'servicios';
                            const message = `Ya agregaste todos los ${label} disponibles. Ajusta la cantidad si necesitas más.`;
                            if (typeof mostrarAlerta === 'function') {
                                mostrarAlerta('warning', message);
                            } else {
                                alert(message);
                            }
                            return;
                        }
                        state.items.push(createEmptyItem(tipo));
                        renderItems();
                    });
                });

                descuentoInput.addEventListener('input', updateResumen);

                const initialItems = (() => {
                    if (!itemsJsonField.value || itemsJsonField.value === '[]') {
                        return [];
                    }
                    try {
                        const parsed = JSON.parse(itemsJsonField.value);
                        return Array.isArray(parsed) ? parsed : [];
                    } catch (error) {
                        return [];
                    }
                })();

                if (initialItems.length) {
                    state.items = initialItems.map((rawItem) => ({
                        tipoItem: rawItem.tipoItem === 'PAQUETE' ? 'PAQUETE' : 'SERVICIO',
                        servicioId: rawItem.servicioId ?? null,
                        paqueteId: rawItem.paqueteId ?? null,
                        cantidad: sanitizeNumber(rawItem.cantidad, 1) || 1,
                        precioUnitario: sanitizeNumber(rawItem.precioUnitario, 0),
                        precioTotal: sanitizeNumber(rawItem.precioTotal, 0),
                        descripcionExtra: rawItem.descripcionExtra ? String(rawItem.descripcionExtra) : ''
                    }));
                }

                if (!state.items.length) {
                    state.items.push(createEmptyItem('SERVICIO'));
                }

                renderItems();

                form.addEventListener('submit', async (event) => {
                    event.preventDefault();

                    if (!token) {
                        if (typeof mostrarAlerta === 'function') {
                            mostrarAlerta('error', 'No se encontró token de sesión. Inicia sesión nuevamente.');
                        } else {
                            alert('No se encontró token de sesión.');
                        }
                        return;
                    }

                    if (!userId) {
                        if (typeof mostrarAlerta === 'function') {
                            mostrarAlerta('error', 'No se pudo identificar al usuario actual.');
                        } else {
                            alert('No se pudo identificar al usuario actual.');
                        }
                        return;
                    }

                    if (!idEmpresa) {
                        if (typeof mostrarAlerta === 'function') {
                            mostrarAlerta('error', 'No se pudo determinar la empresa.');
                        } else {
                            alert('No se pudo determinar la empresa.');
                        }
                        return;
                    }

                    if (!state.items.length) {
                        if (typeof mostrarAlerta === 'function') {
                            mostrarAlerta('error', 'Agrega al menos un servicio o paquete a la reserva.');
                        } else {
                            alert('Agrega al menos un servicio o paquete a la reserva.');
                        }
                        return;
                    }

                    updateResumen();

                    const hasMissingSelection = state.items.some((item) => {
                        if (item.tipoItem === 'PAQUETE') {
                            return !item.paqueteId;
                        }
                        return !item.servicioId;
                    });

                    if (hasMissingSelection) {
                        if (typeof mostrarAlerta === 'function') {
                            mostrarAlerta('error', 'Completa los datos de cada ítem seleccionando el servicio o paquete correspondiente.');
                        } else {
                            alert('Completa los datos de cada ítem seleccionando el servicio o paquete correspondiente.');
                        }
                        return;
                    }

                    if (hasDuplicateSelections()) {
                        if (typeof mostrarAlerta === 'function') {
                            mostrarAlerta('error', 'Cada servicio o paquete solo puede agregarse una vez. Ajusta la cantidad en lugar de duplicarlo.');
                        } else {
                            alert('Cada servicio o paquete solo puede agregarse una vez. Ajusta la cantidad en lugar de duplicarlo.');
                        }
                        return;
                    }

                    itemsJsonField.value = JSON.stringify(state.items);
                    syncAsignacionesField();

                    const formData = new FormData(form);
                    formData.set('token', token);
                    formData.set('idEmpresa', idEmpresa);
                    formData.set('idUsuario', userId);
                    formData.set('ajax', '1');
                    formData.set('crear', '1');

                    const params = new URLSearchParams({ ajax: '1' });
                    if (token) {
                        params.set('token', token);
                    }
                    if (idEmpresa) {
                        params.set('idEmpresa', idEmpresa);
                    }

                    const baseUrl = window.location.origin + window.location.pathname.replace(/\/[^\/]*$/, '/');
                    const requestUrl = baseUrl + 'RESERVAS/nueva_reserva.php?' + params.toString();

                    try {
                        console.log('📤 Enviando solicitud de reserva a:', requestUrl);
                        console.log('📦 Datos del formulario:', Object.fromEntries(formData));
                        
                        const response = await fetch(requestUrl, {
                            method: 'POST',
                            body: formData
                        });

                        console.log('📥 Respuesta recibida - Status:', response.status, response.statusText);

                        if (!response.ok) {
                            const parsedError = await parseErrorResponse(response);
                            if (parsedError.payload) {
                                console.error('❌ Objeto de error:', parsedError.payload);
                            }
                            throw new Error(parsedError.message);
                        }

                        const result = await response.json();
                        console.log('✅ Respuesta JSON:', result);
                        
                        if (result.success) {
                            if (typeof mostrarAlerta === 'function') {
                                mostrarAlerta('success', result.message || 'Reserva creada correctamente');
                            } else {
                                alert(result.message || 'Reserva creada correctamente');
                            }
                            setTimeout(() => {
                                if (typeof loadReservasContent === 'function') {
                                    loadReservasContent();
                                }
                            }, 1200);
                        } else {
                            const formattedError = formatApiError(result, result.message || 'Error al crear la reserva');
                            console.error('❌ La API retornó success=false:', formattedError, result);
                            throw new Error(formattedError);
                        }
                    } catch (error) {
                        console.error('❌ Error completo al crear reserva:', error);
                        console.error('❌ Stack trace:', error.stack);
                        
                        const errorMessage = error.message || 'Error desconocido al crear la reserva';
                        console.error('❌ Mensaje de error final:', errorMessage);
                        const renderedMessage = errorMessage.replace(/\n/g, '<br>');
                        
                        if (typeof mostrarAlerta === 'function') {
                            mostrarAlerta('error', renderedMessage);
                        } else {
                            alert(errorMessage);
                        }
                    }
                });
            })();
        </script>
        <?php
    };

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['ajax'] ?? '') === '1') {
    error_log("=== NUEVA RESERVA: Inicio de procesamiento POST ===");
    error_log("POST data: " . json_encode($_POST, JSON_UNESCAPED_UNICODE));
    
    header('Content-Type: application/json; charset=utf-8');

    if (!$tokenHeader) {
        error_log("ERROR: Token no encontrado");
        http_response_code(401);
        echo json_encode([
            'success' => false,
            'message' => 'No se encontró token de sesión. Inicia sesión nuevamente.'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $clienteId = isset($_POST['clienteId']) ? (int) $_POST['clienteId'] : null;
    error_log("Cliente ID: " . ($clienteId ?? 'NULL'));
    
    if (!$clienteId) {
        error_log("ERROR: Cliente ID inválido");
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'Selecciona un cliente válido.'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $fechaServicio = trim((string) ($_POST['fechaServicio'] ?? ''));
    error_log("Fecha servicio: " . $fechaServicio);
    
    if ($fechaServicio === '') {
        error_log("ERROR: Fecha servicio vacía");
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'La fecha del servicio es obligatoria.'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $fechaReserva = trim((string) ($_POST['fechaReserva'] ?? ''));
    if ($fechaReserva === '') {
        $fechaReserva = date('Y-m-d');
    }
    error_log("Fecha reserva: " . $fechaReserva);

    try {
        error_log("Items JSON recibido: " . ($_POST['items_json'] ?? '[]'));
        $itemsPayload = buildItemsPayload($_POST['items_json'] ?? '[]');
        error_log("Items procesados: " . json_encode($itemsPayload, JSON_UNESCAPED_UNICODE));
    } catch (InvalidArgumentException $exception) {
        error_log("ERROR en buildItemsPayload: " . $exception->getMessage());
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => $exception->getMessage()
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $asignacionesPayload = null;
    try {
        $asignacionesPayload = buildAssignmentsPayload($_POST['asignaciones_json'] ?? null, $fechaServicio);
        error_log('Asignaciones procesadas: ' . json_encode($asignacionesPayload, JSON_UNESCAPED_UNICODE));
    } catch (InvalidArgumentException $exception) {
        error_log('ERROR en buildAssignmentsPayload: ' . $exception->getMessage());
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => $exception->getMessage()
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if (empty($asignacionesPayload)) {
        $asignacionesPayload = null;
    }

    $numeroPersonas = isset($_POST['numeroPersonas']) ? (int) $_POST['numeroPersonas'] : null;
    $numeroDesdeItems = array_reduce($itemsPayload, static function (int $carry, array $item): int {
        return $carry + (int) ($item['cantidad'] ?? 0);
    }, 0);
    if ($numeroDesdeItems <= 0) {
        $numeroDesdeItems = null;
    }
    if ($numeroPersonas === null || $numeroPersonas <= 0) {
        $numeroPersonas = $numeroDesdeItems ?? 1;
    }
    error_log("Número de personas: " . $numeroPersonas);

    $descuentoAplicado = isset($_POST['descuentoAplicado']) ? (float) $_POST['descuentoAplicado'] : 0.0;
    if ($descuentoAplicado < 0) {
        $descuentoAplicado = 0.0;
    }
    error_log("Descuento aplicado: " . $descuentoAplicado);

    $observaciones = trim((string) ($_POST['observaciones'] ?? ''));
    $promocionId = isset($_POST['promocionId']) && $_POST['promocionId'] !== '' ? (int) $_POST['promocionId'] : null;

    foreach ($itemsPayload as &$itemPayload) {
        $itemPayload['precioUnitario'] = (float) number_format((float) $itemPayload['precioUnitario'], 2, '.', '');
        $itemPayload['precioTotal'] = (float) number_format((float) $itemPayload['precioTotal'], 2, '.', '');
        if (!isset($itemPayload['descripcionExtra']) || $itemPayload['descripcionExtra'] === '' || $itemPayload['descripcionExtra'] === null) {
            unset($itemPayload['descripcionExtra']);
        }
    }
    unset($itemPayload);

    $payload = [
        'empresaId' => $idEmpresa ? (int) $idEmpresa : null,
        'clienteId' => $clienteId,
        'promocionId' => $promocionId,
        'fechaServicio' => $fechaServicio,
        'fechaReserva' => $fechaReserva ?: date('Y-m-d'),
        'numeroPersonas' => $numeroPersonas,
        'descuentoAplicado' => (float) number_format($descuentoAplicado, 2, '.', ''),
        'observaciones' => $observaciones !== '' ? $observaciones : null,
        'items' => $itemsPayload,
        'asignaciones' => $asignacionesPayload,
    ];

    $payload = array_filter($payload, static function ($value) {
        return $value !== null;
    });

    error_log("Payload final antes de enviar: " . json_encode($payload, JSON_UNESCAPED_UNICODE));

    $payloadJson = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($payloadJson === false) {
        error_log("ERROR: No se pudo codificar el payload a JSON");
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'No se pudo preparar el payload de la reserva.'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $apiUrl = $apiBase . '/reservas';
    error_log("Enviando POST a API: " . $apiUrl);
    
    $curl = curl_init($apiUrl);
    curl_setopt_array($curl, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $payloadJson,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Authorization: ' . $tokenHeader,
        ],
    ]);

    $apiResponseBody = curl_exec($curl);
    $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $curlError = curl_error($curl);
    curl_close($curl);

    error_log("Respuesta API - HTTP Code: " . $httpCode);
    error_log("Respuesta API - Body: " . substr($apiResponseBody, 0, 500));

    if ($curlError) {
        error_log("ERROR CURL: " . $curlError);
        http_response_code(502);
        echo json_encode([
            'success' => false,
            'message' => 'Error de conexión con la API: ' . $curlError
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $decodedApi = json_decode($apiResponseBody, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        error_log("ERROR: Respuesta API no es JSON válido - " . json_last_error_msg());
        http_response_code($httpCode >= 400 ? $httpCode : 500);
        echo json_encode([
            'success' => false,
            'message' => 'La API devolvió una respuesta inválida: ' . substr($apiResponseBody, 0, 200)
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($httpCode >= 400 || !($decodedApi['success'] ?? false)) {
        $message = $decodedApi['message'] ?? 'Error al crear la reserva';
        error_log("ERROR API: " . $message);
        error_log("Detalles completos: " . json_encode($decodedApi, JSON_UNESCAPED_UNICODE));
        
        http_response_code($httpCode >= 400 ? $httpCode : 400);
        echo json_encode([
            'success' => false,
            'message' => $message,
            'details' => $decodedApi['details'] ?? null,
            'errors' => $decodedApi['errors'] ?? null
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    error_log("=== RESERVA CREADA EXITOSAMENTE ===");
    echo json_encode([
        'success' => true,
        'message' => $decodedApi['message'] ?? 'Reserva creada correctamente',
        'data' => $decodedApi['data'] ?? null,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($tokenHeader) {
    $queryParamsBase = [];
    if ($idEmpresa) {
        $queryParamsBase['empresaId'] = $idEmpresa;
    }
    $queryParamsBase['size'] = 100;

    $buildUrl = static function (string $path, array $params) use ($apiBase): string {
        return $apiBase . $path . (empty($params) ? '' : '?' . http_build_query($params));
    };

    $clientesResult = fetchApiCollection($buildUrl('/clientes', $queryParamsBase), $tokenHeader);
    if ($clientesResult['success']) {
        $clientes = $clientesResult['data'];
    } elseif ($error === null) {
        $error = 'No se pudo cargar la lista de clientes: ' . ($clientesResult['message'] ?? 'Error desconocido');
    }

    $serviciosResult = fetchApiCollection($buildUrl('/servicios', $queryParamsBase), $tokenHeader);
    if ($serviciosResult['success']) {
        $servicios = $serviciosResult['data'];
    } elseif ($error === null) {
        $error = 'No se pudo cargar la lista de servicios: ' . ($serviciosResult['message'] ?? 'Error desconocido');
    }

    $paquetesParams = $queryParamsBase;
    $paquetesParams['size'] = 100;
    $paquetesResult = fetchApiCollection($buildUrl('/paquetes', $paquetesParams), $tokenHeader);
    if ($paquetesResult['success']) {
        $paquetes = $paquetesResult['data'];
    } elseif ($error === null) {
        $error = 'No se pudo cargar la lista de paquetes: ' . ($paquetesResult['message'] ?? 'Error desconocido');
    }
} else {
    if ($error === null) {
        $error = 'No se pudo validar la sesión del usuario. Inicia sesión nuevamente.';
    }
}

if (isset($_GET['ajax']) && $_GET['ajax'] === '1') {
    ob_start();
    $formContent();
    $content = ob_get_clean();
    header('Content-Type: text/html; charset=utf-8');
    echo $content;
    exit;
}

?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nueva Reserva - Sistema de Gestión</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Playfair+Display:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="web.css">
    <link rel="stylesheet" href="alertas.css">
</head>
<body class="admin-body">
    <aside class="admin-sidebar" id="sidebar">
        <div class="sidebar-header">
            <h2 class="sidebar-title">Sistema</h2>
        </div>
        <nav class="sidebar-nav">
            <a href="reservas.php" class="sidebar-link">
                <i class="fas fa-calendar-check"></i>
                <span>Reservas</span>
            </a>
        </nav>
    </aside>

    <main class="admin-main-content" id="mainContent">
        <header class="admin-header">
            <div class="header-left">
                <button class="sidebar-toggle" id="sidebarToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <h1 class="page-title">Nueva Reserva</h1>
            </div>
            <div class="header-right">
                <div class="user-profile">
                    <div class="profile-info">
                        <img src="https://via.placeholder.com/45" alt="Usuario" class="profile-image">
                        <div class="user-info">
                            <span class="user-name">Administrador</span>
                            <span class="user-role">Admin</span>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <div class="admin-content">
            <?php $formContent(); ?>
        </div>
    </main>

    <div id="alertasContainer"></div>

    <script>
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        const mainContent = document.getElementById('mainContent');

        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', function() {
                sidebar.classList.toggle('sidebar-collapsed');
                mainContent.classList.toggle('content-expanded');
            });
        }

        document.addEventListener('click', function(event) {
            if (window.innerWidth <= 1024) {
                if (!sidebar.contains(event.target) && !sidebarToggle.contains(event.target)) {
                    sidebar.classList.remove('sidebar-collapsed');
                    mainContent.classList.remove('content-expanded');
                }
            }
        });

        function mostrarAlerta(arg1, arg2 = 'info', duracion = 5000) {
            const tiposValidos = ['success', 'error', 'warning', 'info'];
            let tipo;
            let mensaje;

            if (typeof arg1 === 'string' && tiposValidos.includes(arg1.toLowerCase())) {
                tipo = arg1.toLowerCase();
                mensaje = typeof arg2 === 'string' ? arg2 : '';
            } else {
                mensaje = typeof arg1 === 'string' ? arg1 : String(arg1 ?? '');
                tipo = typeof arg2 === 'string' && tiposValidos.includes(arg2.toLowerCase())
                    ? arg2.toLowerCase()
                    : 'info';
            }

            if (!mensaje) {
                mensaje = 'Operación realizada';
            }

            let alertasContainer = document.getElementById('alertasContainer');

            if (!alertasContainer) {
                alertasContainer = document.createElement('div');
                alertasContainer.id = 'alertasContainer';
                document.body.appendChild(alertasContainer);
            }

            const alerta = document.createElement('div');
            alerta.className = `alerta alerta-${tipo}`;

            const iconos = {
                success: '<i class="fas fa-check-circle"></i>',
                error: '<i class="fas fa-exclamation-circle"></i>',
                warning: '<i class="fas fa-exclamation-triangle"></i>',
                info: '<i class="fas fa-info-circle"></i>'
            };

            alerta.innerHTML = `
                <div style="display:flex;align-items:center;gap:10px;">
                    ${iconos[tipo] || ''}
                    <span>${mensaje}</span>
                </div>
                <button class="cerrar-alerta" onclick="this.parentElement.remove()">
                    <i class="fas fa-times"></i>
                </button>
            `;

            alertasContainer.appendChild(alerta);

            setTimeout(() => {
                alerta.style.opacity = '1';
                alerta.style.transform = 'translateY(0)';
            }, 10);

            setTimeout(() => {
                alerta.style.opacity = '0';
                alerta.style.transform = 'translateY(-100%)';
                setTimeout(() => {
                    if (alerta.parentNode) {
                        alerta.remove();
                    }
                }, 300);
            }, duracion);
        }
    </script>
</body>
</html>
