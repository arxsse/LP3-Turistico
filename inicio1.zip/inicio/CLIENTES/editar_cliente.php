<?php
// Obtener token del usuario (desde parámetro GET, POST o cookie)
$token = null;
if (isset($_POST['token'])) {
    $token = 'Bearer ' . $_POST['token'];
} elseif (isset($_GET['token'])) {
    $token = 'Bearer ' . $_GET['token'];
} elseif (isset($_COOKIE['userToken'])) {
    $token = 'Bearer ' . $_COOKIE['userToken'];
}

// Si no hay token, usar uno por defecto (para compatibilidad con acceso directo)
if (!$token) {
    $token = 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJjbEBnbWFpbC5jb20iLCJ1c2VySWQiOjE1LCJlbXByZXNhSWQiOjEsInJvbGVzIjpbIlJPTEVfU1VQRVJBRE1JTklTVFJBRE9SIl0sImlzcyI6InNpc3RlbWEtdHVyaXN0aWNvLWJhY2tlbmQiLCJpYXQiOjE3NjQzMzk3MTYsImV4cCI6MTc2NDQyNjExNn0.H-geg1tf1JJI5i7aagghYZJ9NWtL7DQ2Cutz1uB3kqc';
}

$baseUrl = 'http://turistas.spring.informaticapp.com:2410/api/v1/clientes';

// Variables
$cliente = null;
$error = null;
$success = null;
$clienteId = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Obtener idEmpresa si viene como parámetro (GET o POST)
$idEmpresa = isset($_POST['idEmpresa']) ? intval($_POST['idEmpresa']) : (isset($_GET['idEmpresa']) ? intval($_GET['idEmpresa']) : 1);

// Procesar actualización si se envió el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['actualizar'])) {
    $clienteId = isset($_POST['id']) ? intval($_POST['id']) : 0;
    
    // Validar documento (DNI o RUC) si se proporcionó
    $tipoDocumento = $_POST['tipoDocumento'] ?? 'DNI';
    $dni = $_POST['dni'] ?? '';
    if (!empty($dni)) {
        // Validar que el documento tenga la longitud correcta según el tipo
        $dni = preg_replace('/[^0-9]/', '', $dni); // Solo números
        $longitudEsperada = ($tipoDocumento === 'RUC') ? 11 : 8;
        if (strlen($dni) !== $longitudEsperada) {
            $error = "El " . $tipoDocumento . " debe tener exactamente " . $longitudEsperada . " dígitos";
        }
    }
    
    // Si no hay error, proceder con la actualización
    if (!$error) {
        // Obtener idEmpresa del POST si está disponible, sino usar el de GET o el valor por defecto
        $idEmpresaActualizar = isset($_POST['idEmpresa']) ? intval($_POST['idEmpresa']) : $idEmpresa;
        
        // Preparar datos para actualizar según la estructura de la API
        $datosActualizar = [
            'empresa' => ['idEmpresa' => $idEmpresaActualizar],
            'nombre' => $_POST['nombre'] ?? '',
            'apellido' => $_POST['apellido'] ?? '',
            'email' => $_POST['email'] ?? '',
            'telefono' => $_POST['telefono'] ?? '',
            'dni' => $dni,
            'fechaNacimiento' => $_POST['fechaNacimiento'] ?? '',
            'nacionalidad' => $_POST['nacionalidad'] ?? '',
            'preferenciasViaje' => $_POST['preferenciasViaje'] ?? ''
        ];
    
        // Realizar petición PUT a la API
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $baseUrl . '/' . $clienteId,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'PUT',
            CURLOPT_POSTFIELDS => json_encode($datosActualizar),
            CURLOPT_HTTPHEADER => array(
                'Authorization: ' . $token,
                'Content-Type: application/json'
            ),
        ));
        
        $response = curl_exec($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $curlError = curl_error($curl);
        curl_close($curl);
        
        if ($curlError) {
            $error = "Error de conexión: " . $curlError;
        } elseif ($httpCode === 200 || $httpCode === 204) {
            // Si se está cargando vía AJAX, devolver JSON
            if (isset($_GET['ajax']) && $_GET['ajax'] == '1' || isset($_POST['ajax']) && $_POST['ajax'] == '1') {
                header('Content-Type: application/json');
                echo json_encode([
                    'success' => true,
                    'message' => 'Cliente actualizado correctamente'
                ]);
                exit();
            }
            // Redirigir a clientes.php con mensaje de éxito
            header('Location: clientes.php?success=1&mensaje=' . urlencode('Cliente actualizado correctamente'));
            exit();
        } else {
            $error = "Error al actualizar: HTTP " . $httpCode;
            if ($response) {
                $errorData = json_decode($response, true);
                if (isset($errorData['message'])) {
                    $error .= " - " . $errorData['message'];
                }
            }
        }
    }
}

// Obtener datos del cliente
if ($clienteId > 0) {
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => $baseUrl . '/' . $clienteId,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        CURLOPT_HTTPHEADER => array(
            'Authorization: ' . $token
        ),
    ));
    
    $response = curl_exec($curl);
    $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $curlError = curl_error($curl);
    curl_close($curl);
    
    if ($curlError) {
        $error = "Error de conexión: " . $curlError;
    } elseif ($httpCode === 200) {
        $data = json_decode($response, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            // Extraer datos del cliente según la estructura
            if (isset($data['data'])) {
                $cliente = $data['data'];
            } elseif (isset($data['content'])) {
                $cliente = $data['content'];
            } else {
                $cliente = $data;
            }
        } else {
            $error = "Error al decodificar JSON: " . json_last_error_msg();
        }
    } else {
        $error = "Error al obtener cliente: HTTP " . $httpCode;
    }
} else {
    $error = "ID de cliente no válido";
}

// Si se solicita vía AJAX, devolver solo el contenido del formulario
if (isset($_GET['ajax']) && $_GET['ajax'] == '1') {
    ob_start();
    ?>
    <div class="content-header">
        <div class="card">
            <div class="card-header">
                <h2 class="section-title">Editar Cliente</h2>
                <div class="header-actions">
                    <button type="button" class="btn btn-secondary" onclick="if(typeof loadClientesContent === 'function') { loadClientesContent(); } else { window.location.href = 'CLIENTES/clientes.php'; }">
                        <i class="fas fa-arrow-left"></i>
                        Volver
                    </button>
                </div>
            </div>
            <div class="card-body">
                <?php if ($error && !$cliente): ?>
                    <div style="padding: 20px; text-align: center;">
                        <p style="color: #dc3545; font-size: 1.1rem;">
                            <i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?>
                        </p>
                        <button type="button" class="btn btn-secondary" onclick="if(typeof loadClientesContent === 'function') { loadClientesContent(); } else { window.location.href = 'CLIENTES/clientes.php'; }" style="margin-top: 20px;">
                            <i class="fas fa-arrow-left"></i> Volver a Clientes
                        </button>
                    </div>
                <?php elseif ($cliente): ?>
                    <?php 
                    // Determinar el tipo de documento basado en la longitud del DNI
                    $dniCliente = $cliente['dni'] ?? '';
                    $tipoDocumentoCliente = (strlen($dniCliente) === 11) ? 'RUC' : 'DNI';
                    ?>
                    <?php if ($success): ?>
                        <div style="padding: 15px; background: #d4edda; color: #155724; border-radius: 8px; margin-bottom: 20px; border: 1px solid #c3e6cb;">
                            <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($error): ?>
                        <div style="padding: 15px; background: #f8d7da; color: #721c24; border-radius: 8px; margin-bottom: 20px; border: 1px solid #f5c6cb;">
                            <i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="" class="form-container" id="formEditarCliente">
                        <input type="hidden" name="ajax" value="1">
                        <?php 
                        // Obtener ID del cliente
                        $idCliente = $clienteId;
                        if (isset($cliente['id'])) {
                            $idCliente = $cliente['id'];
                        } elseif (isset($cliente['clienteId'])) {
                            $idCliente = $cliente['clienteId'];
                        } elseif (isset($cliente['idCliente'])) {
                            $idCliente = $cliente['idCliente'];
                        }
                        ?>
                        <input type="hidden" name="id" value="<?php echo htmlspecialchars($idCliente); ?>">
                        <input type="hidden" name="idEmpresa" value="<?php echo htmlspecialchars($idEmpresa); ?>">
                        
                        <div class="form-grid">
                            <div class="form-group full-width" style="display: flex; flex-direction: row; gap: 20px; align-items: flex-start;">
                                <div style="flex: 1; display: flex; flex-direction: column; min-width: 0;">
                                    <label class="form-label" for="tipoDocumento">Tipo de Documento</label>
                                    <select 
                                        id="tipoDocumento" 
                                        name="tipoDocumento" 
                                        class="form-input"
                                    >
                                        <option value="DNI" <?php echo ($tipoDocumentoCliente === 'RUC') ? '' : 'selected'; ?>>DNI</option>
                                        <option value="RUC" <?php echo ($tipoDocumentoCliente === 'RUC') ? 'selected' : ''; ?>>RUC</option>
                                    </select>
                                </div>
                                <div style="flex: 1; display: flex; flex-direction: column; min-width: 0;">
                                    <label class="form-label" for="dni" id="labelDocumento"><?php echo $tipoDocumentoCliente; ?></label>
                                    <input 
                                        type="text" 
                                        id="dni" 
                                        name="dni" 
                                        class="form-input" 
                                        value="<?php echo htmlspecialchars($dniCliente); ?>"
                                        maxlength="11"
                                        pattern="[0-9]{8,11}"
                                        placeholder="Ingrese el documento"
                                        title="El documento debe tener 8 dígitos (DNI) o 11 dígitos (RUC)"
                                    >
                                    <small style="color: #6c757d; font-size: 0.85rem; margin-top: 5px; display: block;" id="helpDocumento">
                                        Solo números, <?php echo ($tipoDocumentoCliente === 'RUC') ? '11' : '8'; ?> dígitos para <?php echo $tipoDocumentoCliente; ?>
                                    </small>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label" for="nombre">Nombres o razon social</label>
                                <input 
                                    type="text" 
                                    id="nombre" 
                                    name="nombre" 
                                    class="form-input" 
                                    value="<?php echo htmlspecialchars($cliente['nombre'] ?? $cliente['nombres'] ?? ''); ?>"
                                    required
                                >
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label" for="apellido">Apellidos</label>
                                <input 
                                    type="text" 
                                    id="apellido" 
                                    name="apellido" 
                                    class="form-input" 
                                    value="<?php echo htmlspecialchars($cliente['apellido'] ?? $cliente['apellidos'] ?? ''); ?>"
                                >
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label" for="email">Email</label>
                                <input 
                                    type="email" 
                                    id="email" 
                                    name="email" 
                                    class="form-input" 
                                    value="<?php echo htmlspecialchars($cliente['email'] ?? ''); ?>"
                                    required
                                >
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label" for="telefono">Teléfono</label>
                                <input 
                                    type="tel" 
                                    id="telefono" 
                                    name="telefono" 
                                    class="form-input" 
                                    value="<?php echo htmlspecialchars($cliente['telefono'] ?? $cliente['celular'] ?? ''); ?>"
                                >
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label" for="fechaNacimiento">Fecha de Nacimiento</label>
                                <input 
                                    type="date" 
                                    id="fechaNacimiento" 
                                    name="fechaNacimiento" 
                                    class="form-input" 
                                    value="<?php 
                                        if (isset($cliente['fechaNacimiento'])) {
                                            echo htmlspecialchars($cliente['fechaNacimiento']);
                                        } elseif (isset($cliente['fecha_nacimiento'])) {
                                            echo htmlspecialchars($cliente['fecha_nacimiento']);
                                        }
                                    ?>"
                                >
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label" for="nacionalidad">Nacionalidad</label>
                                <input 
                                    type="text" 
                                    id="nacionalidad" 
                                    name="nacionalidad" 
                                    class="form-input" 
                                    value="<?php echo htmlspecialchars($cliente['nacionalidad'] ?? ''); ?>"
                                >
                            </div>
                            
                            <div class="form-group full-width">
                                <label class="form-label" for="preferenciasViaje">Preferencias de Viaje</label>
                                <textarea 
                                    id="preferenciasViaje" 
                                    name="preferenciasViaje" 
                                    class="form-input" 
                                    rows="3"
                                ><?php echo htmlspecialchars($cliente['preferenciasViaje'] ?? $cliente['preferencias_viaje'] ?? ''); ?></textarea>
                            </div>
                        </div>
                        
                        <div class="form-actions">
                            <button type="submit" name="actualizar" class="btn btn-primary">
                                <i class="fas fa-save"></i>
                                Guardar Cambios
                            </button>
                            <button type="button" class="btn btn-secondary" onclick="if(typeof loadClientesContent === 'function') { loadClientesContent(); } else { window.location.href = 'CLIENTES/clientes.php'; }">
                                <i class="fas fa-times"></i>
                                Cancelar
                            </button>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <script>
        // Función para actualizar el campo de documento según el tipo seleccionado
        function actualizarCampoDocumento() {
            const tipoDocumento = document.getElementById('tipoDocumento');
            const dniInput = document.getElementById('dni');
            const labelDocumento = document.getElementById('labelDocumento');
            const helpDocumento = document.getElementById('helpDocumento');
            
            if (tipoDocumento && dniInput && labelDocumento && helpDocumento) {
                const tipo = tipoDocumento.value;
                
                if (tipo === 'RUC') {
                    labelDocumento.textContent = 'RUC';
                    dniInput.maxLength = 11;
                    dniInput.pattern = '[0-9]{11}';
                    dniInput.placeholder = 'Ingrese 11 dígitos';
                    helpDocumento.textContent = 'Solo números, 11 dígitos para RUC';
                } else {
                    labelDocumento.textContent = 'DNI';
                    dniInput.maxLength = 8;
                    dniInput.pattern = '[0-9]{8}';
                    dniInput.placeholder = 'Ingrese 8 dígitos';
                    helpDocumento.textContent = 'Solo números, 8 dígitos para DNI';
                }
            }
        }
        
        // Función para buscar por documento
        function buscarPorDocumento() {
            const tipoDocumento = document.getElementById('tipoDocumento').value;
            const documento = document.getElementById('dni').value;
            
            if (!documento) {
                if (typeof mostrarAlerta === 'function') {
                    mostrarAlerta('warning', 'Por favor ingrese un ' + tipoDocumento + ' para buscar');
                } else {
                    alert('Por favor ingrese un ' + tipoDocumento + ' para buscar');
                }
                return;
            }
            
            // Validar longitud según el tipo
            const longitudEsperada = tipoDocumento === 'RUC' ? 11 : 8;
            if (documento.length !== longitudEsperada) {
                if (typeof mostrarAlerta === 'function') {
                    mostrarAlerta('warning', 'El ' + tipoDocumento + ' debe tener exactamente ' + longitudEsperada + ' dígitos');
                } else {
                    alert('El ' + tipoDocumento + ' debe tener exactamente ' + longitudEsperada + ' dígitos');
                }
                return;
            }
            
            // Deshabilitar el botón mientras se busca
            const btnBuscar = document.getElementById('btnBuscarDocumento');
            const btnOriginalText = btnBuscar.innerHTML;
            btnBuscar.disabled = true;
            btnBuscar.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Buscando...';
            
            // Mostrar mensaje de búsqueda
            if (typeof mostrarAlerta === 'function') {
                mostrarAlerta('info', 'Buscando información del ' + tipoDocumento + '...');
            }
            
            // Realizar petición AJAX
            const urlBusqueda = 'CLIENTES/buscar_cliente.php?tipo=' + encodeURIComponent(tipoDocumento) + '&documento=' + encodeURIComponent(documento) + '&debug=1';
            console.log('🔍 Realizando búsqueda:', urlBusqueda);
            
            fetch(urlBusqueda)
                .then(response => {
                    console.log('📥 Respuesta recibida - Status:', response.status);
                    if (!response.ok) {
                        return response.text().then(text => {
                            console.error('❌ Error HTTP:', text);
                            throw new Error('HTTP error! status: ' + response.status);
                        });
                    }
                    return response.json();
                })
                .then(data => {
                    // Restaurar el botón
                    btnBuscar.disabled = false;
                    btnBuscar.innerHTML = btnOriginalText;
                    
                    console.log('📋 Respuesta completa:', JSON.stringify(data, null, 2));
                    
                    if (data.success) {
                        // Llenar los campos del formulario con los datos encontrados
                        if (data.datos) {
                            console.log('✅ Datos recibidos:', data.datos);
                            
                            let camposLlenados = 0;
                            
                            // Para DNI: separar nombre y apellidos
                            if (tipoDocumento === 'DNI') {
                                const nombreField = document.getElementById('nombre');
                                const apellidoField = document.getElementById('apellido');
                                
                                if (nombreField && data.datos.nombre && data.datos.nombre.trim()) {
                                    nombreField.value = data.datos.nombre.trim();
                                    camposLlenados++;
                                }
                                
                                if (apellidoField) {
                                    if (data.datos.apellido && data.datos.apellido.trim()) {
                                        apellidoField.value = data.datos.apellido.trim();
                                        camposLlenados++;
                                    } else if ((data.datos.apellidoPaterno && data.datos.apellidoPaterno.trim()) || 
                                               (data.datos.apellidoMaterno && data.datos.apellidoMaterno.trim())) {
                                        const apellidos = [
                                            data.datos.apellidoPaterno || '',
                                            data.datos.apellidoMaterno || ''
                                        ].filter(a => a && a.trim()).join(' ').trim();
                                        if (apellidos) {
                                            apellidoField.value = apellidos;
                                            camposLlenados++;
                                        }
                                    }
                                }
                            } else {
                                // Para RUC: el nombre completo va en el campo nombre
                                const nombreField = document.getElementById('nombre');
                                
                                if (nombreField) {
                                    const nombreCompleto = (
                                        data.datos.nombre || 
                                        data.datos.nombreCompleto || 
                                        data.datos.razonSocial ||
                                        data.datos.denominacion ||
                                        ''
                                    ).trim();
                                    
                                    if (nombreCompleto) {
                                        nombreField.value = nombreCompleto;
                                        camposLlenados++;
                                    }
                                }
                            }
                            
                            if (camposLlenados > 0) {
                                if (typeof mostrarAlerta === 'function') {
                                    mostrarAlerta('success', 'Información del ' + tipoDocumento + ' encontrada y cargada');
                                }
                            } else {
                                if (typeof mostrarAlerta === 'function') {
                                    mostrarAlerta('warning', 'Se encontró el ' + tipoDocumento + ' pero no se pudo cargar información adicional');
                                }
                            }
                        }
                    } else {
                        console.error('❌ Búsqueda fallida:', data.message);
                        if (typeof mostrarAlerta === 'function') {
                            mostrarAlerta('error', data.message || 'No se encontró información para el ' + tipoDocumento);
                        } else {
                            alert(data.message || 'No se encontró información para el ' + tipoDocumento);
                        }
                    }
                })
                .catch(error => {
                    // Restaurar el botón
                    btnBuscar.disabled = false;
                    btnBuscar.innerHTML = btnOriginalText;
                    
                    console.error('❌ Error al buscar:', error);
                    if (typeof mostrarAlerta === 'function') {
                        mostrarAlerta('error', 'Error al buscar el ' + tipoDocumento + '. Por favor intente nuevamente.');
                    } else {
                        alert('Error al buscar el ' + tipoDocumento + '. Por favor intente nuevamente.');
                    }
                });
        }
        
        // Event listener para el cambio de tipo de documento
        const tipoDocumentoSelect = document.getElementById('tipoDocumento');
        if (tipoDocumentoSelect) {
            tipoDocumentoSelect.addEventListener('change', actualizarCampoDocumento);
        }
        
        // Validación del documento en tiempo real
        const dniInput = document.getElementById('dni');
        if (dniInput) {
            dniInput.addEventListener('input', function(e) {
                // Solo permitir números
                this.value = this.value.replace(/[^0-9]/g, '');
                
                // Limitar según el tipo de documento
                const tipoDocumento = document.getElementById('tipoDocumento').value;
                const maxLength = tipoDocumento === 'RUC' ? 11 : 8;
                
                if (this.value.length > maxLength) {
                    this.value = this.value.slice(0, maxLength);
                }
            });
            
            dniInput.addEventListener('blur', function(e) {
                // Validar al salir del campo
                const tipoDocumento = document.getElementById('tipoDocumento').value;
                const longitudEsperada = tipoDocumento === 'RUC' ? 11 : 8;
                
                if (this.value.length > 0 && this.value.length !== longitudEsperada) {
                    if (typeof mostrarAlerta === 'function') {
                        mostrarAlerta('warning', 'El ' + tipoDocumento + ' debe tener exactamente ' + longitudEsperada + ' dígitos');
                    } else {
                        alert('El ' + tipoDocumento + ' debe tener exactamente ' + longitudEsperada + ' dígitos');
                    }
                    this.focus();
                }
            });
        }
        
        // Manejar envío del formulario vía AJAX
        const form = document.getElementById('formEditarCliente');
        if (form) {
            form.addEventListener('submit', async function(e) {
                e.preventDefault();
                
                const tipoDocumento = document.getElementById('tipoDocumento').value;
                const documento = document.getElementById('dni').value;
                const longitudEsperada = tipoDocumento === 'RUC' ? 11 : 8;
                
                if (documento && documento.length !== longitudEsperada) {
                    if (typeof mostrarAlerta === 'function') {
                        mostrarAlerta('error', 'El ' + tipoDocumento + ' debe tener exactamente ' + longitudEsperada + ' dígitos');
                    } else {
                        alert('El ' + tipoDocumento + ' debe tener exactamente ' + longitudEsperada + ' dígitos');
                    }
                    document.getElementById('dni').focus();
                    return false;
                }
                
                // Obtener datos del formulario
                const formData = new FormData(form);
                
                // Obtener token del usuario
                const userDataStr = sessionStorage.getItem('userData') || localStorage.getItem('userData');
                let token = null;
                let idEmpresa = null;
                
                if (userDataStr) {
                    try {
                        const userData = JSON.parse(userDataStr);
                        token = userData.token;
                        idEmpresa = userData.empresaId;
                    } catch (e) {
                        console.error('Error al parsear userData:', e);
                    }
                }
                
                // Agregar token e idEmpresa al FormData si están disponibles
                if (token) {
                    formData.append('token', token);
                }
                if (idEmpresa) {
                    formData.append('idEmpresa', idEmpresa);
                }
                formData.append('ajax', '1');
                formData.append('actualizar', '1');
                
                // Construir URL
                let url = 'CLIENTES/editar_cliente.php?ajax=1&id=' + encodeURIComponent(formData.get('id'));
                if (idEmpresa) {
                    url += '&idEmpresa=' + encodeURIComponent(idEmpresa);
                }
                if (token) {
                    url += '&token=' + encodeURIComponent(token);
                }
                
                try {
                    const response = await fetch(url, {
                        method: 'POST',
                        body: formData
                    });
                    
                    if (response.ok) {
                        const result = await response.json();
                        if (result.success) {
                            if (typeof mostrarAlerta === 'function') {
                                mostrarAlerta('success', result.message || 'Cliente actualizado correctamente');
                            } else {
                                alert(result.message || 'Cliente actualizado correctamente');
                            }
                            // Recargar la lista de clientes
                            setTimeout(() => {
                                if (typeof loadClientesContent === 'function') {
                                    loadClientesContent();
                                } else {
                                    window.location.href = 'admin.php#clientes';
                                }
                            }, 1500);
                        } else {
                            throw new Error(result.message || 'Error al actualizar cliente');
                        }
                    } else {
                        const errorText = await response.text();
                        throw new Error('Error HTTP: ' + response.status);
                    }
                } catch (error) {
                    console.error('Error al actualizar cliente:', error);
                    if (typeof mostrarAlerta === 'function') {
                        mostrarAlerta('error', error.message || 'Error al actualizar el cliente');
                    } else {
                        alert(error.message || 'Error al actualizar el cliente');
                    }
                }
            });
        }
    </script>
    <?php
    $content = ob_get_clean();
    header('Content-Type: text/html; charset=utf-8');
    echo $content;
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Cliente - Sistema de Gestión</title>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Playfair+Display:wght@400;700&display=swap" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- CSS -->
    <link rel="stylesheet" href="web.css">
    <link rel="stylesheet" href="alertas.css">
</head>
<body class="admin-body">
    <!-- Sidebar -->
    <aside class="admin-sidebar" id="sidebar">
        <div class="sidebar-header">
            <h2 class="sidebar-title">Sistema</h2>
        </div>
        <nav class="sidebar-nav">
            <a href="clientes.php" class="sidebar-link">
                <i class="fas fa-users"></i>
                <span>Clientes</span>
            </a>
        </nav>
    </aside>

    <!-- Contenido Principal -->
    <main class="admin-main-content" id="mainContent">
        <!-- Header -->
        <header class="admin-header">
            <div class="header-left">
                <button class="sidebar-toggle" id="sidebarToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <h1 class="page-title">Editar Cliente</h1>
            </div>
            <div class="header-right">
                <div class="user-profile">
                    <div class="profile-info">
                        <img src="https://via.placeholder.com/45" alt="Usuario" class="profile-image">
                        <div class="user-info">
                            <span class="user-name">Administrador</span>
                            <span class="user-role">Admin</span>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Contenido -->
        <div class="admin-content">
            <div class="content-header">
                <div class="card">
                    <div class="card-header">
                        <h2 class="section-title">Editar Cliente</h2>
                        <div class="header-actions">
                            <a href="clientes.php" class="btn btn-secondary">
                                <i class="fas fa-arrow-left"></i>
                                Volver
                            </a>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if ($error && !$cliente): ?>
                            <div style="padding: 20px; text-align: center;">
                                <p style="color: #dc3545; font-size: 1.1rem;">
                                    <i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?>
                                </p>
                                <a href="clientes.php" class="btn btn-secondary" style="margin-top: 20px;">
                                    <i class="fas fa-arrow-left"></i> Volver a Clientes
                                </a>
                            </div>
                        <?php elseif ($cliente): ?>
                            <?php 
                            // Determinar el tipo de documento basado en la longitud del DNI
                            $dniCliente = $cliente['dni'] ?? '';
                            $tipoDocumentoCliente = (strlen($dniCliente) === 11) ? 'RUC' : 'DNI';
                            ?>
                            <?php if ($success): ?>
                                <div style="padding: 15px; background: #d4edda; color: #155724; border-radius: 8px; margin-bottom: 20px; border: 1px solid #c3e6cb;">
                                    <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($error): ?>
                                <div style="padding: 15px; background: #f8d7da; color: #721c24; border-radius: 8px; margin-bottom: 20px; border: 1px solid #f5c6cb;">
                                    <i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?>
                                </div>
                            <?php endif; ?>
                            
                            <form method="POST" action="" class="form-container">
                                <?php 
                                // Obtener ID del cliente
                                $idCliente = $clienteId;
                                if (isset($cliente['id'])) {
                                    $idCliente = $cliente['id'];
                                } elseif (isset($cliente['clienteId'])) {
                                    $idCliente = $cliente['clienteId'];
                                } elseif (isset($cliente['idCliente'])) {
                                    $idCliente = $cliente['idCliente'];
                                }
                                ?>
                                <input type="hidden" name="id" value="<?php echo htmlspecialchars($idCliente); ?>">
                                
                                <div class="form-grid">
                                    <div class="form-group full-width" style="display: flex; flex-direction: row; gap: 20px; align-items: flex-start;">
                                        <div style="flex: 1; display: flex; flex-direction: column; min-width: 0;">
                                            <label class="form-label" for="tipoDocumento2">Tipo de Documento</label>
                                            <select 
                                                id="tipoDocumento2" 
                                                name="tipoDocumento" 
                                                class="form-input"
                                            >
                                                <option value="DNI" <?php echo ($tipoDocumentoCliente === 'RUC') ? '' : 'selected'; ?>>DNI</option>
                                                <option value="RUC" <?php echo ($tipoDocumentoCliente === 'RUC') ? 'selected' : ''; ?>>RUC</option>
                                            </select>
                                        </div>
                                        <div style="flex: 1; display: flex; flex-direction: column; min-width: 0;">
                                            <label class="form-label" for="dni2" id="labelDocumento2"><?php echo $tipoDocumentoCliente; ?></label>
                                            <input 
                                                type="text" 
                                                id="dni2" 
                                                name="dni" 
                                                class="form-input" 
                                                value="<?php echo htmlspecialchars($dniCliente); ?>"
                                                maxlength="11"
                                                pattern="[0-9]{8,11}"
                                                placeholder="Ingrese el documento"
                                                title="El documento debe tener 8 dígitos (DNI) o 11 dígitos (RUC)"
                                            >
                                            <small style="color: #6c757d; font-size: 0.85rem; margin-top: 5px; display: block;" id="helpDocumento2">
                                                Solo números, <?php echo ($tipoDocumentoCliente === 'RUC') ? '11' : '8'; ?> dígitos para <?php echo $tipoDocumentoCliente; ?>
                                            </small>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="form-label" for="nombre2">Nombres o razon social</label>
                                        <input 
                                            type="text" 
                                            id="nombre2" 
                                            name="nombre" 
                                            class="form-input" 
                                            value="<?php echo htmlspecialchars($cliente['nombre'] ?? $cliente['nombres'] ?? ''); ?>"
                                            required
                                        >
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="form-label" for="apellido2">Apellidos</label>
                                        <input 
                                            type="text" 
                                            id="apellido2" 
                                            name="apellido" 
                                            class="form-input" 
                                            value="<?php echo htmlspecialchars($cliente['apellido'] ?? $cliente['apellidos'] ?? ''); ?>"
                                        >
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="form-label" for="email2">Email</label>
                                        <input 
                                            type="email" 
                                            id="email2" 
                                            name="email" 
                                            class="form-input" 
                                            value="<?php echo htmlspecialchars($cliente['email'] ?? ''); ?>"
                                            required
                                        >
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="form-label" for="telefono2">Teléfono</label>
                                        <input 
                                            type="tel" 
                                            id="telefono2" 
                                            name="telefono" 
                                            class="form-input" 
                                            value="<?php echo htmlspecialchars($cliente['telefono'] ?? $cliente['celular'] ?? ''); ?>"
                                        >
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="form-label" for="fechaNacimiento">Fecha de Nacimiento</label>
                                        <input 
                                            type="date" 
                                            id="fechaNacimiento" 
                                            name="fechaNacimiento" 
                                            class="form-input" 
                                            value="<?php 
                                                if (isset($cliente['fechaNacimiento'])) {
                                                    echo htmlspecialchars($cliente['fechaNacimiento']);
                                                } elseif (isset($cliente['fecha_nacimiento'])) {
                                                    echo htmlspecialchars($cliente['fecha_nacimiento']);
                                                }
                                            ?>"
                                        >
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="form-label" for="nacionalidad">Nacionalidad</label>
                                        <input 
                                            type="text" 
                                            id="nacionalidad" 
                                            name="nacionalidad" 
                                            class="form-input" 
                                            value="<?php echo htmlspecialchars($cliente['nacionalidad'] ?? ''); ?>"
                                        >
                                    </div>
                                    
                                    <div class="form-group full-width">
                                        <label class="form-label" for="preferenciasViaje">Preferencias de Viaje</label>
                                        <textarea 
                                            id="preferenciasViaje" 
                                            name="preferenciasViaje" 
                                            class="form-input" 
                                            rows="3"
                                        ><?php echo htmlspecialchars($cliente['preferenciasViaje'] ?? $cliente['preferencias_viaje'] ?? ''); ?></textarea>
                                    </div>
                                </div>
                                
                                <div class="form-actions">
                                    <button type="submit" name="actualizar" class="btn btn-primary">
                                        <i class="fas fa-save"></i>
                                        Guardar Cambios
                                    </button>
                                    <a href="clientes.php" class="btn btn-secondary">
                                        <i class="fas fa-times"></i>
                                        Cancelar
                                    </a>
                                </div>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Contenedor para alertas -->
    <div id="alertasContainer"></div>

    <!-- JavaScript -->
    <script>
        // Toggle sidebar en móviles
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        const mainContent = document.getElementById('mainContent');

        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', function() {
                sidebar.classList.toggle('sidebar-collapsed');
                mainContent.classList.toggle('content-expanded');
            });
        }

        // Cerrar sidebar al hacer clic fuera en móviles
        document.addEventListener('click', function(event) {
            if (window.innerWidth <= 1024) {
                if (!sidebar.contains(event.target) && !sidebarToggle.contains(event.target)) {
                    sidebar.classList.remove('sidebar-collapsed');
                    mainContent.classList.remove('content-expanded');
                }
            }
        });

        // Función para mostrar alertas
        function mostrarAlerta(tipo, mensaje, duracion = 5000) {
            const alertasContainer = document.getElementById('alertasContainer');
            
            if (!alertasContainer) {
                const container = document.createElement('div');
                container.id = 'alertasContainer';
                document.body.appendChild(container);
            }
            
            const alerta = document.createElement('div');
            alerta.className = `alerta alerta-${tipo}`;
            
            const iconos = {
                success: '<i class="fas fa-check-circle"></i>',
                error: '<i class="fas fa-exclamation-circle"></i>',
                warning: '<i class="fas fa-exclamation-triangle"></i>',
                info: '<i class="fas fa-info-circle"></i>'
            };
            
            alerta.innerHTML = `
                <div style="display: flex; align-items: center; gap: 10px;">
                    ${iconos[tipo] || ''}
                    <span>${mensaje}</span>
                </div>
                <button class="cerrar-alerta" onclick="this.parentElement.remove()">
                    <i class="fas fa-times"></i>
                </button>
            `;
            
            alertasContainer.appendChild(alerta);
            
            setTimeout(() => {
                alerta.style.opacity = '1';
                alerta.style.transform = 'translateY(0)';
            }, 10);
            
            setTimeout(() => {
                alerta.style.opacity = '0';
                alerta.style.transform = 'translateY(-100%)';
                setTimeout(() => {
                    if (alerta.parentNode) {
                        alerta.remove();
                    }
                }, 300);
            }, duracion);
        }

        // Exportar función globalmente
        window.mostrarAlerta = mostrarAlerta;
        
        // Función para actualizar el campo de documento según el tipo seleccionado (versión 2)
        function actualizarCampoDocumento2() {
            const tipoDocumento = document.getElementById('tipoDocumento2');
            const dniInput = document.getElementById('dni2');
            const labelDocumento = document.getElementById('labelDocumento2');
            const helpDocumento = document.getElementById('helpDocumento2');
            
            if (tipoDocumento && dniInput && labelDocumento && helpDocumento) {
                const tipo = tipoDocumento.value;
                
                if (tipo === 'RUC') {
                    labelDocumento.textContent = 'RUC';
                    dniInput.maxLength = 11;
                    dniInput.pattern = '[0-9]{11}';
                    dniInput.placeholder = 'Ingrese 11 dígitos';
                    helpDocumento.textContent = 'Solo números, 11 dígitos para RUC';
                } else {
                    labelDocumento.textContent = 'DNI';
                    dniInput.maxLength = 8;
                    dniInput.pattern = '[0-9]{8}';
                    dniInput.placeholder = 'Ingrese 8 dígitos';
                    helpDocumento.textContent = 'Solo números, 8 dígitos para DNI';
                }
            }
        }
        
        // Función para buscar por documento (versión 2)
        function buscarPorDocumento2() {
            const tipoDocumento = document.getElementById('tipoDocumento2').value;
            const documento = document.getElementById('dni2').value;
            
            if (!documento) {
                mostrarAlerta('warning', 'Por favor ingrese un ' + tipoDocumento + ' para buscar');
                return;
            }
            
            // Validar longitud según el tipo
            const longitudEsperada = tipoDocumento === 'RUC' ? 11 : 8;
            if (documento.length !== longitudEsperada) {
                mostrarAlerta('warning', 'El ' + tipoDocumento + ' debe tener exactamente ' + longitudEsperada + ' dígitos');
                return;
            }
            
            // Deshabilitar el botón mientras se busca
            const btnBuscar = document.getElementById('btnBuscarDocumento2');
            const btnOriginalText = btnBuscar.innerHTML;
            btnBuscar.disabled = true;
            btnBuscar.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Buscando...';
            
            // Mostrar mensaje de búsqueda
            mostrarAlerta('info', 'Buscando información del ' + tipoDocumento + '...');
            
            // Realizar petición AJAX
            const urlBusqueda = 'CLIENTES/buscar_cliente.php?tipo=' + encodeURIComponent(tipoDocumento) + '&documento=' + encodeURIComponent(documento) + '&debug=1';
            console.log('🔍 Realizando búsqueda:', urlBusqueda);
            
            fetch(urlBusqueda)
                .then(response => {
                    console.log('📥 Respuesta recibida - Status:', response.status);
                    if (!response.ok) {
                        return response.text().then(text => {
                            console.error('❌ Error HTTP:', text);
                            throw new Error('HTTP error! status: ' + response.status);
                        });
                    }
                    return response.json();
                })
                .then(data => {
                    // Restaurar el botón
                    btnBuscar.disabled = false;
                    btnBuscar.innerHTML = btnOriginalText;
                    
                    console.log('📋 Respuesta completa:', JSON.stringify(data, null, 2));
                    
                    if (data.success) {
                        // Llenar los campos del formulario con los datos encontrados
                        if (data.datos) {
                            console.log('✅ Datos recibidos:', data.datos);
                            
                            let camposLlenados = 0;
                            
                            // Para DNI: separar nombre y apellidos
                            if (tipoDocumento === 'DNI') {
                                const nombreField = document.getElementById('nombre2');
                                const apellidoField = document.getElementById('apellido2');
                                
                                if (nombreField && data.datos.nombre && data.datos.nombre.trim()) {
                                    nombreField.value = data.datos.nombre.trim();
                                    camposLlenados++;
                                }
                                
                                if (apellidoField) {
                                    if (data.datos.apellido && data.datos.apellido.trim()) {
                                        apellidoField.value = data.datos.apellido.trim();
                                        camposLlenados++;
                                    } else if ((data.datos.apellidoPaterno && data.datos.apellidoPaterno.trim()) || 
                                               (data.datos.apellidoMaterno && data.datos.apellidoMaterno.trim())) {
                                        const apellidos = [
                                            data.datos.apellidoPaterno || '',
                                            data.datos.apellidoMaterno || ''
                                        ].filter(a => a && a.trim()).join(' ').trim();
                                        if (apellidos) {
                                            apellidoField.value = apellidos;
                                            camposLlenados++;
                                        }
                                    }
                                }
                            } else {
                                // Para RUC: el nombre completo va en el campo nombre
                                const nombreField = document.getElementById('nombre2');
                                
                                if (nombreField) {
                                    const nombreCompleto = (
                                        data.datos.nombre || 
                                        data.datos.nombreCompleto || 
                                        data.datos.razonSocial ||
                                        data.datos.denominacion ||
                                        ''
                                    ).trim();
                                    
                                    if (nombreCompleto) {
                                        nombreField.value = nombreCompleto;
                                        camposLlenados++;
                                    }
                                }
                            }
                            
                            if (camposLlenados > 0) {
                                mostrarAlerta('success', 'Información del ' + tipoDocumento + ' encontrada y cargada');
                            } else {
                                mostrarAlerta('warning', 'Se encontró el ' + tipoDocumento + ' pero no se pudo cargar información adicional');
                            }
                        }
                    } else {
                        console.error('❌ Búsqueda fallida:', data.message);
                        mostrarAlerta('error', data.message || 'No se encontró información para el ' + tipoDocumento);
                    }
                })
                .catch(error => {
                    // Restaurar el botón
                    btnBuscar.disabled = false;
                    btnBuscar.innerHTML = btnOriginalText;
                    
                    console.error('❌ Error al buscar:', error);
                    mostrarAlerta('error', 'Error al buscar el ' + tipoDocumento + '. Por favor intente nuevamente.');
                });
        }
        
        // Event listener para el cambio de tipo de documento (versión 2)
        const tipoDocumentoSelect2 = document.getElementById('tipoDocumento2');
        if (tipoDocumentoSelect2) {
            tipoDocumentoSelect2.addEventListener('change', actualizarCampoDocumento2);
        }
        
        // Validación del documento en tiempo real (versión 2)
        const dniInput2 = document.getElementById('dni2');
        if (dniInput2) {
            dniInput2.addEventListener('input', function(e) {
                // Solo permitir números
                this.value = this.value.replace(/[^0-9]/g, '');
                
                // Limitar según el tipo de documento
                const tipoDocumento = document.getElementById('tipoDocumento2').value;
                const maxLength = tipoDocumento === 'RUC' ? 11 : 8;
                
                if (this.value.length > maxLength) {
                    this.value = this.value.slice(0, maxLength);
                }
            });
            
            dniInput2.addEventListener('blur', function(e) {
                // Validar al salir del campo
                const tipoDocumento = document.getElementById('tipoDocumento2').value;
                const longitudEsperada = tipoDocumento === 'RUC' ? 11 : 8;
                
                if (this.value.length > 0 && this.value.length !== longitudEsperada) {
                    mostrarAlerta('warning', 'El ' + tipoDocumento + ' debe tener exactamente ' + longitudEsperada + ' dígitos');
                    this.focus();
                }
            });
        }
        
        // Validación del formulario antes de enviar
        const form = document.querySelector('form');
        if (form) {
            form.addEventListener('submit', function(e) {
                const tipoDocumento = document.getElementById('tipoDocumento2') ? document.getElementById('tipoDocumento2').value : 'DNI';
                const dni = document.getElementById('dni2') ? document.getElementById('dni2').value : '';
                const longitudEsperada = tipoDocumento === 'RUC' ? 11 : 8;
                
                if (dni && dni.length !== longitudEsperada) {
                    e.preventDefault();
                    mostrarAlerta('error', 'El ' + tipoDocumento + ' debe tener exactamente ' + longitudEsperada + ' dígitos');
                    const dniField = document.getElementById('dni2') || document.getElementById('dni');
                    if (dniField) dniField.focus();
                    return false;
                }
            });
        }
        
        // Mostrar alerta de éxito si existe
        <?php if ($success): ?>
            mostrarAlerta('success', '<?php echo addslashes($success); ?>');
        <?php endif; ?>
        
        // Mostrar alerta de error si existe
        <?php if ($error && $cliente): ?>
            mostrarAlerta('error', '<?php echo addslashes($error); ?>');
        <?php endif; ?>
    </script>
</body>
</html>

