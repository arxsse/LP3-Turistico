<?php
// Obtener token del usuario (desde parámetro GET, POST o cookie)
$tokenRaw = null;
if (isset($_POST['token'])) {
    $tokenRaw = $_POST['token'];
} elseif (isset($_GET['token'])) {
    $tokenRaw = $_GET['token'];
} elseif (isset($_COOKIE['userToken'])) {
    $tokenRaw = $_COOKIE['userToken'];
}

// Si no hay token, usar uno por defecto (para compatibilidad con acceso directo)
if (!$tokenRaw) {
    $tokenRaw = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJjbEBnbWFpbC5jb20iLCJ1c2VySWQiOjE1LCJlbXByZXNhSWQiOjEsInJvbGVzIjpbIlJPTEVfU1VQRVJBRE1JTklTVFJBRE9SIl0sImlzcyI6InNpc3RlbWEtdHVyaXN0aWNvLWJhY2tlbmQiLCJpYXQiOjE3NjQzMzk3MTYsImV4cCI6MTc2NDQyNjExNn0.H-geg1tf1JJI5i7aagghYZJ9NWtL7DQ2Cutz1uB3kqc';
}

// Preparar token con Bearer para el header
$token = 'Bearer ' . $tokenRaw;

$baseUrl = 'http://turistas.spring.informaticapp.com:2410/api/v1/clientes';

// Variables
$error = null;
$success = null;

// Obtener idEmpresa si viene como parámetro (GET o POST)
$idEmpresa = isset($_POST['idEmpresa']) ? intval($_POST['idEmpresa']) : (isset($_GET['idEmpresa']) ? intval($_GET['idEmpresa']) : 1);

// Obtener idSucursal si viene como parámetro (GET o POST)
$idSucursal = isset($_POST['idSucursal']) ? intval($_POST['idSucursal']) : (isset($_GET['idSucursal']) ? intval($_GET['idSucursal']) : null);

// Procesar creación si se envió el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['crear']) || isset($_GET['ajax']))) {
    // Validar documento (DNI o RUC) si se proporcionó
    $tipoDocumento = $_POST['tipoDocumento'] ?? 'DNI';
    $dni = $_POST['dni'] ?? '';
    if (!empty($dni)) {
        // Validar que el documento tenga la longitud correcta según el tipo
        $dni = preg_replace('/[^0-9]/', '', $dni); // Solo números
        $longitudEsperada = ($tipoDocumento === 'RUC') ? 11 : 8;
        if (strlen($dni) !== $longitudEsperada) {
            $error = "El " . $tipoDocumento . " debe tener exactamente " . $longitudEsperada . " dígitos";
        }
    }
    
    // Si no hay error, verificar si el cliente ya existe antes de crear
    if (!$error && !empty($dni)) {
        // Consultar la API para verificar si ya existe un cliente con este DNI
        $curlVerificar = curl_init();
        curl_setopt_array($curlVerificar, array(
            CURLOPT_URL => $baseUrl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(
                'Authorization: ' . $token
            ),
        ));
        
        $responseVerificar = curl_exec($curlVerificar);
        $httpCodeVerificar = curl_getinfo($curlVerificar, CURLINFO_HTTP_CODE);
        curl_close($curlVerificar);
        
        // Si la consulta fue exitosa, buscar si existe un cliente con el mismo DNI
        if ($httpCodeVerificar === 200 && $responseVerificar) {
            $dataVerificar = json_decode($responseVerificar, true);
            
            // Extraer array de clientes según diferentes estructuras posibles
            $clientes = [];
            if (isset($dataVerificar['data']) && is_array($dataVerificar['data'])) {
                $clientes = $dataVerificar['data'];
            } elseif (isset($dataVerificar['content']) && is_array($dataVerificar['content'])) {
                $clientes = $dataVerificar['content'];
            } elseif (isset($dataVerificar['clientes']) && is_array($dataVerificar['clientes'])) {
                $clientes = $dataVerificar['clientes'];
            } elseif (isset($dataVerificar['items']) && is_array($dataVerificar['items'])) {
                $clientes = $dataVerificar['items'];
            } elseif (isset($dataVerificar['results']) && is_array($dataVerificar['results'])) {
                $clientes = $dataVerificar['results'];
            } elseif (is_array($dataVerificar) && !empty($dataVerificar) && isset($dataVerificar[0])) {
                $clientes = $dataVerificar;
            }
            
            // Buscar si existe un cliente con el mismo DNI
            foreach ($clientes as $clienteExistente) {
                $dniExistente = '';
                if (isset($clienteExistente['dni'])) {
                    $dniExistente = preg_replace('/[^0-9]/', '', $clienteExistente['dni']);
                } elseif (isset($clienteExistente['numeroDocumento'])) {
                    $dniExistente = preg_replace('/[^0-9]/', '', $clienteExistente['numeroDocumento']);
                } elseif (isset($clienteExistente['documento'])) {
                    $dniExistente = preg_replace('/[^0-9]/', '', $clienteExistente['documento']);
                }
                
                if ($dniExistente === $dni) {
                    $error = "El cliente con " . $tipoDocumento . " " . $dni . " ya existe en el sistema";
                    break;
                }
            }
        }
    }
    
    // Si no hay error, proceder con la creación
    if (!$error) {
        // Preparar datos para crear según la estructura de la API (adaptado del ejemplo proporcionado)
        $datosCrear = [
            'nombre' => trim($_POST['nombre'] ?? ''),
            'apellido' => trim($_POST['apellido'] ?? ''),
            'email' => trim($_POST['email'] ?? ''),
            'telefono' => trim($_POST['telefono'] ?? ''),
            'dni' => $dni,
            'fechaNacimiento' => !empty($_POST['fechaNacimiento']) ? $_POST['fechaNacimiento'] : null,
            'nacionalidad' => trim($_POST['nacionalidad'] ?? ''),
            'preferenciasViaje' => trim($_POST['preferenciasViaje'] ?? ''),
            'empresa' => [
                'idEmpresa' => intval($idEmpresa)
            ]
        ];
        
        // Agregar sucursal solo si se proporcionó idSucursal
        if ($idSucursal !== null && $idSucursal > 0) {
            $datosCrear['sucursal'] = [
                'idSucursal' => intval($idSucursal)
            ];
        }
        
        // Agregar nivelMembresia si se proporciona (opcional)
        if (isset($_POST['nivelMembresia']) && !empty(trim($_POST['nivelMembresia']))) {
            $datosCrear['nivelMembresia'] = trim($_POST['nivelMembresia']);
        }
    
        // Realizar petición POST a la API (adaptado del ejemplo proporcionado)
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $baseUrl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode($datosCrear),
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'Authorization: ' . $token
            ),
        ));
        
        $response = curl_exec($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $curlError = curl_error($curl);
        curl_close($curl);
        
        if ($curlError) {
            $error = "Error de conexión: " . $curlError;
        } elseif ($httpCode === 200 || $httpCode === 201) {
            // Si se está cargando vía AJAX, devolver JSON
            if (isset($_GET['ajax']) && $_GET['ajax'] == '1') {
                header('Content-Type: application/json');
                echo json_encode([
                    'success' => true,
                    'message' => 'Cliente creado correctamente'
                ]);
                exit();
            }
            // Redirigir a index.php con mensaje de éxito
            header('Location: clientes.php?success=1&mensaje=' . urlencode('Cliente creado correctamente'));
            exit();
        } else {
            $error = "Error al crear cliente: HTTP " . $httpCode;
            if ($response) {
                $errorData = json_decode($response, true);
                $mensajeError = '';
                if (isset($errorData['message'])) {
                    $mensajeError = $errorData['message'];
                } elseif (isset($errorData['error'])) {
                    $mensajeError = $errorData['error'];
                }
                
                // Verificar si el mensaje indica que el cliente ya existe
                $mensajeLower = strtolower($mensajeError);
                if (strpos($mensajeLower, 'ya existe') !== false || 
                    strpos($mensajeLower, 'already exists') !== false ||
                    strpos($mensajeLower, 'duplicado') !== false ||
                    strpos($mensajeLower, 'duplicate') !== false ||
                    $httpCode === 409) {
                    $error = "El cliente con " . $tipoDocumento . " " . $dni . " ya existe en el sistema";
                } else {
                    $error .= " - " . $mensajeError;
                }
            }
        }
    }
    
    // Si hay error y se está cargando vía AJAX, devolver JSON con el error
    if ($error && isset($_GET['ajax']) && $_GET['ajax'] == '1') {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => $error
        ]);
        exit();
    }
}

// Si se solicita vía AJAX, devolver solo el contenido del formulario
if (isset($_GET['ajax']) && $_GET['ajax'] == '1') {
    ob_start();
    ?>
    <div class="content-header">
        <div class="card">
            <div class="card-header">
                <h2 class="section-title">Crear Nuevo Cliente</h2>
                <div class="header-actions">
                    <button type="button" class="btn btn-secondary" onclick="loadClientesContent()">
                        <i class="fas fa-arrow-left"></i>
                        Volver
                    </button>
                </div>
            </div>
            <div class="card-body">
                <?php if ($error): ?>
                    <div style="padding: 15px; background: #f8d7da; color: #721c24; border-radius: 8px; margin-bottom: 20px; border: 1px solid #f5c6cb;">
                        <i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="javascript:void(0);" class="form-container" id="formNuevoCliente" onsubmit="event.preventDefault(); event.stopPropagation(); return false;">
                    <input type="hidden" name="ajax" value="1">
                    <input type="hidden" name="idEmpresa" value="<?php echo htmlspecialchars($idEmpresa); ?>">
                    <div class="form-grid">
                        <div class="form-group full-width" style="display: flex; flex-direction: row; gap: 20px; align-items: flex-start;">
                            <div style="flex: 1; display: flex; flex-direction: column; min-width: 0;">
                                <label class="form-label" for="tipoDocumento">Tipo de Documento</label>
                                <select 
                                    id="tipoDocumento" 
                                    name="tipoDocumento" 
                                    class="form-input"
                                >
                                    <option value="DNI" <?php echo (isset($_POST['tipoDocumento']) && $_POST['tipoDocumento'] === 'RUC') ? '' : 'selected'; ?>>DNI</option>
                                    <option value="RUC" <?php echo (isset($_POST['tipoDocumento']) && $_POST['tipoDocumento'] === 'RUC') ? 'selected' : ''; ?>>RUC</option>
                                </select>
                            </div>
                            <div style="flex: 1; display: flex; flex-direction: column; min-width: 0;">
                                <label class="form-label" for="dni" id="labelDocumento">DNI</label>
                                <div style="display: flex; gap: 10px; align-items: flex-start;">
                                    <input 
                                        type="text" 
                                        id="dni" 
                                        name="dni" 
                                        class="form-input" 
                                        value="<?php echo htmlspecialchars($_POST['dni'] ?? ''); ?>"
                                        maxlength="11"
                                        pattern="[0-9]{8,11}"
                                        placeholder="Ingrese el documento"
                                        title="El documento debe tener 8 dígitos (DNI) o 11 dígitos (RUC)"
                                        style="flex: 1; min-width: 0;"
                                    >
                                    <button 
                                        type="button" 
                                        id="btnBuscarDocumento"
                                        class="btn btn-secondary"
                                        style="white-space: nowrap; padding: 10px 20px; flex-shrink: 0;"
                                        onclick="buscarPorDocumento()"
                                    >
                                        <i class="fas fa-search"></i>
                                        Buscar
                                    </button>
                                </div>
                                <small style="color: #6c757d; font-size: 0.85rem; margin-top: 5px; display: block;" id="helpDocumento">
                                    Solo números, 8 dígitos para DNI
                                </small>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label" for="nombre">Nombres o razon social<span style="color: #dc3545;">*</span></label>
                            <input 
                                type="text" 
                                id="nombre" 
                                name="nombre" 
                                class="form-input" 
                                value="<?php echo htmlspecialchars($_POST['nombre'] ?? ''); ?>"
                                required
                                placeholder="Ingrese el nombre"
                            >
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label" for="apellido">Apellidos</label>
                            <input 
                                type="text" 
                                id="apellido" 
                                name="apellido" 
                                class="form-input" 
                                value="<?php echo htmlspecialchars($_POST['apellido'] ?? ''); ?>"
                                placeholder="Ingrese el apellido"
                            >
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label" for="email">Email <span style="color: #dc3545;">*</span></label>
                            <input 
                                type="email" 
                                id="email" 
                                name="email" 
                                class="form-input" 
                                value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                                required
                                placeholder="ejemplo@email.com"
                            >
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label" for="telefono">Teléfono</label>
                            <input 
                                type="tel" 
                                id="telefono" 
                                name="telefono" 
                                class="form-input" 
                                value="<?php echo htmlspecialchars($_POST['telefono'] ?? ''); ?>"
                                placeholder="Ingrese el teléfono"
                            >
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label" for="fechaNacimiento">Fecha de Nacimiento</label>
                            <input 
                                type="date" 
                                id="fechaNacimiento" 
                                name="fechaNacimiento" 
                                class="form-input" 
                                value="<?php echo htmlspecialchars($_POST['fechaNacimiento'] ?? ''); ?>"
                            >
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label" for="nacionalidad">Nacionalidad</label>
                            <input 
                                type="text" 
                                id="nacionalidad" 
                                name="nacionalidad" 
                                class="form-input" 
                                value="<?php echo htmlspecialchars($_POST['nacionalidad'] ?? ''); ?>"
                                placeholder="Ej: Peruano"
                            >
                        </div>
                        
                        <div class="form-group full-width">
                            <label class="form-label" for="preferenciasViaje">Preferencias de Viaje</label>
                            <textarea 
                                id="preferenciasViaje" 
                                name="preferenciasViaje" 
                                class="form-input" 
                                rows="3"
                                placeholder="Ej: Aventura, cultura y gastronomía"
                            ><?php echo htmlspecialchars($_POST['preferenciasViaje'] ?? ''); ?></textarea>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" name="crear" class="btn btn-primary">
                            <i class="fas fa-save"></i>
                            Guardar Cliente
                        </button>
                        <button type="button" class="btn btn-secondary" onclick="loadClientesContent()">
                            <i class="fas fa-times"></i>
                            Cancelar
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script>
        // Función para mostrar alertas (compatibilidad con admin.php)
        // Guardar referencia a la función original de admin.php si existe
        const adminMostrarAlerta = typeof window.mostrarAlerta === 'function' ? window.mostrarAlerta : null;
        
        function mostrarAlerta(tipo, mensaje, duracion = 5000) {
            // Usar la función de admin.php si existe y es diferente a esta (evitar recursión)
            if (adminMostrarAlerta && adminMostrarAlerta !== mostrarAlerta) {
                try {
                    // La función de admin.php usa (mensaje, tipo) - invertir parámetros
                    adminMostrarAlerta(mensaje, tipo);
                    return; // Salir, ya se mostró
                } catch (e) {
                    console.error('Error al llamar mostrarAlerta de admin.php:', e);
                    // Continuar con la implementación local
                }
            }
            
            // Buscar contenedor existente o crear uno nuevo
            let alertasContainer = document.getElementById('alertasContainer') || document.getElementById('alertContainer');
            if (!alertasContainer) {
                alertasContainer = document.createElement('div');
                alertasContainer.id = 'alertasContainer';
                alertasContainer.style.cssText = 'position: fixed; top: 20px; right: 20px; z-index: 10000; max-width: 400px;';
                document.body.appendChild(alertasContainer);
            }
            
            const alerta = document.createElement('div');
            alerta.className = `alerta alerta-${tipo}`;
            alerta.style.cssText = 'padding: 15px; margin-bottom: 10px; border-radius: 8px; display: flex; justify-content: space-between; align-items: center; background: ' + 
                (tipo === 'error' ? '#f8d7da; color: #721c24; border: 1px solid #f5c6cb' :
                 tipo === 'success' ? '#d4edda; color: #155724; border: 1px solid #c3e6cb' :
                 tipo === 'warning' ? '#fff3cd; color: #856404; border: 1px solid #ffeeba' :
                 '#d1ecf1; color: #0c5460; border: 1px solid #bee5eb');
            
            const iconos = {
                success: '<i class="fas fa-check-circle"></i>',
                error: '<i class="fas fa-exclamation-circle"></i>',
                warning: '<i class="fas fa-exclamation-triangle"></i>',
                info: '<i class="fas fa-info-circle"></i>'
            };
            
            alerta.innerHTML = `
                <div style="display: flex; align-items: center; gap: 10px; flex: 1;">
                    ${iconos[tipo] || ''}
                    <span>${mensaje}</span>
                </div>
                <button onclick="this.parentElement.remove()" style="background: none; border: none; cursor: pointer; font-size: 18px; color: inherit; opacity: 0.7;">&times;</button>
            `;
            
            alertasContainer.appendChild(alerta);
            
            // Animación de entrada
            setTimeout(() => {
                alerta.style.opacity = '1';
                alerta.style.transform = 'translateY(0)';
            }, 10);
            
            // Auto cerrar después de la duración especificada
            setTimeout(() => {
                alerta.style.opacity = '0';
                alerta.style.transform = 'translateY(-100%)';
                setTimeout(() => {
                    if (alerta.parentNode) {
                        alerta.remove();
                    }
                }, 300);
            }, duracion);
        }
        
        // Exportar globalmente solo si no existe una función de admin.php
        if (!adminMostrarAlerta) {
            window.mostrarAlerta = mostrarAlerta;
        }
        
        // Nota: buscarPorDocumento y actualizarCampoDocumento se definen más abajo
        // y se exportan globalmente después de su definición completa
        
        // Función para actualizar el campo de documento según el tipo seleccionado
        function actualizarCampoDocumento() {
            const tipoDocumento = document.getElementById('tipoDocumento');
            const dniInput = document.getElementById('dni');
            const labelDocumento = document.getElementById('labelDocumento');
            const helpDocumento = document.getElementById('helpDocumento');
            
            if (tipoDocumento && dniInput && labelDocumento && helpDocumento) {
                const tipo = tipoDocumento.value;
                
                if (tipo === 'RUC') {
                    labelDocumento.textContent = 'RUC';
                    dniInput.maxLength = 11;
                    dniInput.pattern = '[0-9]{11}';
                    dniInput.placeholder = 'Ingrese 11 dígitos';
                    helpDocumento.textContent = 'Solo números, 11 dígitos para RUC';
                } else {
                    labelDocumento.textContent = 'DNI';
                    dniInput.maxLength = 8;
                    dniInput.pattern = '[0-9]{8}';
                    dniInput.placeholder = 'Ingrese 8 dígitos';
                    helpDocumento.textContent = 'Solo números, 8 dígitos para DNI';
                }
                
                // Limpiar el campo al cambiar de tipo
                dniInput.value = '';
            }
        }
        
        // Función para buscar por documento
        function buscarPorDocumento() {
            const tipoDocumento = document.getElementById('tipoDocumento').value;
            const documento = document.getElementById('dni').value;
            
            if (!documento) {
                if (typeof mostrarAlerta === 'function') {
                    mostrarAlerta('warning', 'Por favor ingrese un ' + tipoDocumento + ' para buscar');
                } else {
                    alert('Por favor ingrese un ' + tipoDocumento + ' para buscar');
                }
                return;
            }
            
            // Validar longitud según el tipo
            const longitudEsperada = tipoDocumento === 'RUC' ? 11 : 8;
            if (documento.length !== longitudEsperada) {
                if (typeof mostrarAlerta === 'function') {
                    mostrarAlerta('warning', 'El ' + tipoDocumento + ' debe tener exactamente ' + longitudEsperada + ' dígitos');
                } else {
                    alert('El ' + tipoDocumento + ' debe tener exactamente ' + longitudEsperada + ' dígitos');
                }
                return;
            }
            
            // Deshabilitar el botón mientras se busca
            const btnBuscar = document.getElementById('btnBuscarDocumento');
            const btnOriginalText = btnBuscar.innerHTML;
            btnBuscar.disabled = true;
            btnBuscar.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Buscando...';
            
            // Mostrar mensaje de búsqueda
            if (typeof mostrarAlerta === 'function') {
                mostrarAlerta('info', 'Buscando información del ' + tipoDocumento + '...');
            }
            
            // Realizar petición AJAX
            const urlBusqueda = 'CLIENTES/buscar_cliente.php?tipo=' + encodeURIComponent(tipoDocumento) + '&documento=' + encodeURIComponent(documento) + '&debug=1';
            console.log('🔍 Realizando búsqueda:', urlBusqueda);
            
            fetch(urlBusqueda)
                .then(response => {
                    console.log('📥 Respuesta recibida - Status:', response.status);
                    if (!response.ok) {
                        return response.text().then(text => {
                            console.error('❌ Error HTTP:', text);
                            throw new Error('HTTP error! status: ' + response.status);
                        });
                    }
                    return response.json();
                })
                .then(data => {
                    // Restaurar el botón
                    btnBuscar.disabled = false;
                    btnBuscar.innerHTML = btnOriginalText;
                    
                    console.log('📋 Respuesta completa:', JSON.stringify(data, null, 2)); // Debug completo
                    
                    if (data.success) {
                        // Llenar los campos del formulario con los datos encontrados
                        if (data.datos) {
                            console.log('✅ Datos recibidos:', data.datos);
                            
                            let camposLlenados = 0;
                            
                            // Para DNI: separar nombre y apellidos
                            if (tipoDocumento === 'DNI') {
                                const nombreField = document.getElementById('nombre');
                                const apellidoField = document.getElementById('apellido');
                                
                                console.log('🔎 Buscando campos en DOM...');
                                console.log('  - Campo nombre:', nombreField ? '✓ encontrado' : '✗ NO encontrado');
                                console.log('  - Campo apellido:', apellidoField ? '✓ encontrado' : '✗ NO encontrado');
                                
                                if (nombreField) {
                                    if (data.datos.nombre && data.datos.nombre.trim()) {
                                        nombreField.value = data.datos.nombre.trim();
                                        camposLlenados++;
                                        console.log('✓ Nombre asignado:', data.datos.nombre);
                                    } else {
                                        console.warn('⚠ Nombre vacío o no disponible');
                                    }
                                } else {
                                    console.error('✗ Campo nombre no encontrado en el DOM');
                                }
                                
                                if (apellidoField) {
                                    if (data.datos.apellido && data.datos.apellido.trim()) {
                                        apellidoField.value = data.datos.apellido.trim();
                                        camposLlenados++;
                                        console.log('✓ Apellido asignado:', data.datos.apellido);
                                    } else if ((data.datos.apellidoPaterno && data.datos.apellidoPaterno.trim()) || 
                                               (data.datos.apellidoMaterno && data.datos.apellidoMaterno.trim())) {
                                        const apellidos = [
                                            data.datos.apellidoPaterno || '',
                                            data.datos.apellidoMaterno || ''
                                        ].filter(a => a && a.trim()).join(' ').trim();
                                        if (apellidos) {
                                            apellidoField.value = apellidos;
                                            camposLlenados++;
                                            console.log('✓ Apellidos combinados:', apellidos);
                                        }
                                    } else {
                                        console.warn('⚠ Apellido vacío o no disponible');
                                        console.log('📋 Todos los campos disponibles en data.datos:', Object.keys(data.datos));
                                        console.log('📋 Valores de campos relacionados con apellidos:');
                                        console.log('  - apellido:', data.datos.apellido);
                                        console.log('  - apellidos:', data.datos.apellidos);
                                        console.log('  - apellidoPaterno:', data.datos.apellidoPaterno);
                                        console.log('  - apellidoMaterno:', data.datos.apellidoMaterno);
                                        if (data.debug && data.debug.camposDisponibles) {
                                            console.log('📋 Campos disponibles en la respuesta de la API:', data.debug.camposDisponibles);
                                        }
                                    }
                                } else {
                                    console.error('✗ Campo apellido no encontrado en el DOM');
                                }
                            } else {
                                // Para RUC: el nombre completo va en el campo nombre
                                const nombreField = document.getElementById('nombre');
                                console.log('🔎 Buscando campo nombre (RUC):', nombreField ? '✓ encontrado' : '✗ NO encontrado');
                                console.log('📋 Datos recibidos para RUC:', data.datos);
                                
                                if (nombreField) {
                                    // Intentar múltiples campos posibles que la API puede devolver
                                    const nombreCompleto = (
                                        data.datos.nombre || 
                                        data.datos.nombreCompleto || 
                                        data.datos.razonSocial ||
                                        data.datos.denominacion ||
                                        ''
                                    ).trim();
                                    
                                    if (nombreCompleto) {
                                        nombreField.value = nombreCompleto;
                                        camposLlenados++;
                                        console.log('✓ Nombre RUC asignado:', nombreCompleto);
                                    } else {
                                        console.warn('⚠ Nombre RUC vacío o no disponible');
                                        console.log('📋 Todos los campos disponibles en data.datos:', Object.keys(data.datos));
                                        if (data.debug && data.debug.camposDisponibles) {
                                            console.log('📋 Campos disponibles en la respuesta de la API:', data.debug.camposDisponibles);
                                        }
                                        if (data.debug && data.debug.rawResponse) {
                                            console.log('🔍 Respuesta cruda de la API:', data.debug.rawResponse);
                                        }
                                    }
                                } else {
                                    console.error('✗ Campo nombre no encontrado en el DOM');
                                }
                            }
                            
                            console.log(`📊 Total de campos llenados: ${camposLlenados}`);
                            
                            if (camposLlenados === 0) {
                                console.warn('⚠ Ningún campo fue llenado. Verificar estructura de datos.');
                                if (data.debug && data.debug.rawResponse) {
                                    console.log('🔍 Respuesta cruda de la API:', data.debug.rawResponse);
                                }
                            }
                        } else {
                            console.warn('⚠ No se recibieron datos en la respuesta');
                            console.log('Estructura completa de data:', data);
                        }
                        
                        if (typeof mostrarAlerta === 'function') {
                            mostrarAlerta('success', 'Información del ' + tipoDocumento + ' encontrada y cargada');
                        }
                    } else {
                        console.error('❌ Búsqueda fallida:', data.message);
                        if (typeof mostrarAlerta === 'function') {
                            mostrarAlerta('error', data.message || 'No se encontró información para el ' + tipoDocumento);
                        } else {
                            alert(data.message || 'No se encontró información para el ' + tipoDocumento);
                        }
                    }
                })
                .catch(error => {
                    // Restaurar el botón
                    btnBuscar.disabled = false;
                    btnBuscar.innerHTML = btnOriginalText;
                    
                    console.error('❌ Error al buscar:', error);
                    if (typeof mostrarAlerta === 'function') {
                        mostrarAlerta('error', 'Error al buscar el ' + tipoDocumento + '. Por favor intente nuevamente.');
                    } else {
                        alert('Error al buscar el ' + tipoDocumento + '. Por favor intente nuevamente.');
                    }
                });
        }
        
        // Exportar funciones globalmente para que estén disponibles en onclick handlers
        window.buscarPorDocumento = buscarPorDocumento;
        window.actualizarCampoDocumento = actualizarCampoDocumento;
        
        // Event listener para el cambio de tipo de documento
        const tipoDocumentoSelect = document.getElementById('tipoDocumento');
        if (tipoDocumentoSelect) {
            tipoDocumentoSelect.addEventListener('change', actualizarCampoDocumento);
        }
        
        // Validación del documento en tiempo real
        const dniInput = document.getElementById('dni');
        if (dniInput) {
            dniInput.addEventListener('input', function(e) {
                // Solo permitir números
                this.value = this.value.replace(/[^0-9]/g, '');
                
                // Limitar según el tipo de documento
                const tipoDocumento = document.getElementById('tipoDocumento').value;
                const maxLength = tipoDocumento === 'RUC' ? 11 : 8;
                
                if (this.value.length > maxLength) {
                    this.value = this.value.slice(0, maxLength);
                }
            });
            
            dniInput.addEventListener('blur', function(e) {
                // Validar al salir del campo
                const tipoDocumento = document.getElementById('tipoDocumento').value;
                const longitudEsperada = tipoDocumento === 'RUC' ? 11 : 8;
                
                if (this.value.length > 0 && this.value.length !== longitudEsperada) {
                    if (typeof mostrarAlerta === 'function') {
                        mostrarAlerta('warning', 'El ' + tipoDocumento + ' debe tener exactamente ' + longitudEsperada + ' dígitos');
                    } else {
                        alert('El ' + tipoDocumento + ' debe tener exactamente ' + longitudEsperada + ' dígitos');
                    }
                    this.focus();
                }
            });
        }
        
        // Manejar envío del formulario vía AJAX
        // Función para configurar el manejador del formulario
        function setupFormSubmitHandler() {
            const form = document.getElementById('formNuevoCliente');
            if (!form) {
                console.warn('⚠️ Formulario no encontrado, reintentando...');
                setTimeout(setupFormSubmitHandler, 100);
                return;
            }
            
            console.log('🔧 Configurando event listener del formulario...');
            
            // Verificar si ya tiene un listener personalizado (para evitar duplicados)
            // Usar una marca única en el formulario
            const handlerKey = '__ajaxSubmitHandler';
            if (form[handlerKey]) {
                console.log('🗑️ Listener anterior encontrado, removiendo...');
                form.removeEventListener('submit', form[handlerKey]);
                form[handlerKey] = null;
            }
            
            // Crear el handler
            const submitHandler = async function(e) {
                // Siempre prevenir el envío normal del formulario
                e.preventDefault();
                e.stopPropagation();
                e.stopImmediatePropagation();
                
                console.log('✅ Formulario enviado por AJAX - preventDefault ejecutado');
                
                // Deshabilitar el botón de submit para evitar doble envío
                const submitButton = this.querySelector('button[type="submit"], button[name="crear"]');
                const originalButtonText = submitButton ? submitButton.innerHTML : '';
                if (submitButton) {
                    submitButton.disabled = true;
                    submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Guardando...';
                }
                
                const tipoDocumento = document.getElementById('tipoDocumento');
                const dniInput = document.getElementById('dni');
                
                if (!tipoDocumento || !dniInput) {
                    console.error('Elementos del formulario no encontrados');
                    if (submitButton) {
                        submitButton.disabled = false;
                        submitButton.innerHTML = originalButtonText;
                    }
                    return false;
                }
                
                const tipoDoc = tipoDocumento.value;
                const documento = dniInput.value;
                const longitudEsperada = tipoDoc === 'RUC' ? 11 : 8;
                
                if (documento && documento.length !== longitudEsperada) {
                    if (typeof mostrarAlerta === 'function') {
                        mostrarAlerta('error', 'El ' + tipoDoc + ' debe tener exactamente ' + longitudEsperada + ' dígitos');
                    } else {
                        alert('El ' + tipoDoc + ' debe tener exactamente ' + longitudEsperada + ' dígitos');
                    }
                    dniInput.focus();
                    if (submitButton) {
                        submitButton.disabled = false;
                        submitButton.innerHTML = originalButtonText;
                    }
                    return false;
                }
                
                // Obtener datos del formulario
                const formData = new FormData(this);
                
                // Obtener token del usuario
                const userDataStr = sessionStorage.getItem('userData') || localStorage.getItem('userData');
                let token = null;
                let idEmpresa = null;
                let idSucursal = null;
                
                if (userDataStr) {
                    try {
                        const userData = JSON.parse(userDataStr);
                        token = userData.token;
                        idEmpresa = userData.empresaId;
                        // Obtener idSucursal del userData si está disponible
                        idSucursal = userData.sucursalId || userData.idSucursal || null;
                    } catch (e) {
                        console.error('Error al parsear userData:', e);
                    }
                }
                
                // Agregar token, idEmpresa e idSucursal al FormData si están disponibles
                if (token) {
                    formData.append('token', token);
                }
                if (idEmpresa) {
                    formData.append('idEmpresa', idEmpresa);
                }
                if (idSucursal) {
                    formData.append('idSucursal', idSucursal);
                }
                formData.append('ajax', '1');
                formData.append('crear', '1');
                
                // Construir URL
                let url = 'CLIENTES/nuevo_cliente.php?ajax=1';
                if (idEmpresa) {
                    url += '&idEmpresa=' + encodeURIComponent(idEmpresa);
                }
                if (idSucursal) {
                    url += '&idSucursal=' + encodeURIComponent(idSucursal);
                }
                if (token) {
                    url += '&token=' + encodeURIComponent(token);
                }
                
                console.log('📡 Enviando petición AJAX a:', url);
                
                try {
                    const response = await fetch(url, {
                        method: 'POST',
                        body: formData
                    });
                    
                    console.log('📥 Respuesta recibida - Status:', response.status);
                    
                    const responseText = await response.text();
                    let result;
                    
                    try {
                        result = JSON.parse(responseText);
                    } catch (e) {
                        // Si no es JSON, intentar extraer el mensaje de error del HTML
                        const parser = new DOMParser();
                        const doc = parser.parseFromString(responseText, 'text/html');
                        const errorDiv = doc.querySelector('[style*="background: #f8d7da"]') || 
                                       doc.querySelector('.alert-danger') ||
                                       doc.querySelector('[class*="error"]');
                        
                        if (errorDiv) {
                            const errorText = errorDiv.textContent.trim();
                            throw new Error(errorText || 'Error al crear el cliente');
                        }
                        throw new Error('Error al procesar la respuesta del servidor');
                    }
                    
                    if (response.ok) {
                        if (result && result.success) {
                            // Rehabilitar el botón antes de mostrar el mensaje
                            if (submitButton) {
                                submitButton.disabled = false;
                                submitButton.innerHTML = originalButtonText;
                            }
                            
                            if (typeof mostrarAlerta === 'function') {
                                mostrarAlerta('success', result.message || 'Cliente creado correctamente');
                            } else {
                                alert(result.message || 'Cliente creado correctamente');
                            }
                            
                            // Regresar a la lista de clientes después de mostrar el mensaje de éxito
                            setTimeout(() => {
                                if (typeof loadClientesContent === 'function') {
                                    loadClientesContent();
                                } else if (typeof window.loadClientesContent === 'function') {
                                    window.loadClientesContent();
                                } else {
                                    // Si no existe la función, intentar recargar la página
                                    window.location.href = 'admin.php#clientes';
                                }
                            }, 1500);
                        } else {
                            // Cuando success es false, hay un error
                            let mensajeError = 'Error al crear el cliente';
                            
                            if (result && result.message) {
                                mensajeError = result.message;
                            } else if (result && result.error) {
                                mensajeError = result.error;
                            } else if (typeof result === 'string') {
                                mensajeError = result;
                            }
                            
                            // Verificar si el mensaje indica que el cliente ya existe y formatear el mensaje
                            const mensajeLower = mensajeError.toLowerCase();
                            if (mensajeLower.indexOf('ya existe') !== -1 || 
                                mensajeLower.indexOf('already exists') !== -1 ||
                                mensajeLower.indexOf('duplicado') !== -1 ||
                                mensajeLower.indexOf('duplicate') !== -1) {
                                // Asegurar mensaje claro y específico
                                if (documento) {
                                    mensajeError = 'El cliente con ' + tipoDocumento + ' ' + documento + ' ya existe en el sistema';
                                } else {
                                    mensajeError = 'El cliente ya existe en el sistema';
                                }
                            }
                            
                            console.log('Error detectado - success: false, mensaje:', mensajeError);
                            throw new Error(mensajeError);
                        }
                    } else {
                        // Manejar errores de la API
                        let mensajeError = 'Error al crear el cliente';
                        
                        if (result && result.message) {
                            mensajeError = result.message;
                        } else if (result && result.error) {
                            mensajeError = result.error;
                        } else if (result && typeof result === 'object') {
                            // Intentar encontrar cualquier campo que contenga el mensaje
                            mensajeError = result.message || result.error || result.msg || JSON.stringify(result);
                        }
                        
                        // Verificar si el mensaje indica que el cliente ya existe
                        const mensajeLower = mensajeError.toLowerCase();
                        if (mensajeLower.indexOf('ya existe') !== -1 || 
                            mensajeLower.indexOf('already exists') !== -1 ||
                            mensajeLower.indexOf('duplicado') !== -1 ||
                            mensajeLower.indexOf('duplicate') !== -1 ||
                            response.status === 409) {
                            mensajeError = 'El cliente con ' + tipoDocumento + ' ' + documento + ' ya existe en el sistema';
                        }
                        
                        throw new Error(mensajeError);
                    }
                } catch (error) {
                    console.error('Error al crear cliente:', error);
                    
                    // Rehabilitar el botón en caso de error
                    if (submitButton) {
                        submitButton.disabled = false;
                        submitButton.innerHTML = originalButtonText;
                    }
                    
                    let mensajeError = error.message || 'Error al crear el cliente';
                    
                    // Asegurar que el mensaje específico de "cliente ya existe" se muestre claramente
                    const mensajeLower = mensajeError.toLowerCase();
                    if (mensajeLower.indexOf('ya existe') !== -1 || 
                        mensajeLower.indexOf('already exists') !== -1 ||
                        mensajeLower.indexOf('duplicado') !== -1 ||
                        mensajeLower.indexOf('duplicate') !== -1) {
                        // Extraer tipo de documento y número si están en el mensaje
                        const tipoDoc = document.getElementById('tipoDocumento')?.value || 'documento';
                        const docNum = document.getElementById('dni')?.value || '';
                        if (docNum) {
                            mensajeError = 'El cliente con ' + tipoDoc + ' ' + docNum + ' ya existe en el sistema';
                        } else {
                            mensajeError = 'El cliente ya existe en el sistema';
                        }
                    }
                    
                    console.log('Mostrando error:', mensajeError);
                    
                    // Usar la función mostrarAlerta definida arriba (ya maneja la compatibilidad)
                    if (typeof mostrarAlerta === 'function') {
                        try {
                            mostrarAlerta('error', mensajeError);
                        } catch (e) {
                            console.error('Error al llamar mostrarAlerta:', e);
                            alert(mensajeError);
                        }
                    } else {
                        // Fallback: alert nativo y mostrar en el formulario
                        alert(mensajeError);
                        const form = document.getElementById('formNuevoCliente');
                        if (form) {
                            let errorDiv = form.querySelector('.error-message');
                            if (!errorDiv) {
                                errorDiv = document.createElement('div');
                                errorDiv.className = 'error-message';
                                errorDiv.style.cssText = 'padding: 15px; background: #f8d7da; color: #721c24; border-radius: 8px; margin-bottom: 20px; border: 1px solid #f5c6cb; position: relative; z-index: 1000;';
                                form.insertBefore(errorDiv, form.firstChild);
                            }
                            errorDiv.innerHTML = '<i class="fas fa-exclamation-triangle"></i> <strong>' + mensajeError + '</strong>';
                            errorDiv.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                        }
                    }
                }
            };
            
            // Guardar referencia al handler en el formulario
            form[handlerKey] = submitHandler;
            
            // Agregar el event listener al formulario
            form.addEventListener('submit', submitHandler);
            
            // También agregar onsubmit como fallback adicional
            form.onsubmit = function(e) {
                e.preventDefault();
                e.stopPropagation();
                return false;
            };
            
            console.log('✅ Event listener de formulario configurado correctamente');
        }
        
        // Exportar función globalmente para que pueda ser llamada desde admin.php
        window.setupFormSubmitHandler = setupFormSubmitHandler;
        
        // Configurar el manejador del formulario cuando se carga el script
        // Ejecutar inmediatamente y también después de pequeños delays para asegurar que funcione
        setupFormSubmitHandler();
        setTimeout(setupFormSubmitHandler, 100);
        setTimeout(setupFormSubmitHandler, 300);
        setTimeout(setupFormSubmitHandler, 500);
    </script>
    <?php
    $content = ob_get_clean();
    header('Content-Type: text/html; charset=utf-8');
    echo $content;
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nuevo Cliente - Sistema de Gestión</title>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Playfair+Display:wght@400;700&display=swap" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- CSS -->
    <link rel="stylesheet" href="web.css">
    <link rel="stylesheet" href="alertas.css">
</head>
<body class="admin-body">
    <!-- Sidebar -->
    <aside class="admin-sidebar" id="sidebar">
        <div class="sidebar-header">
            <h2 class="sidebar-title">Sistema</h2>
        </div>
        <nav class="sidebar-nav">
            <a href="index.php" class="sidebar-link">
                <i class="fas fa-users"></i>
                <span>Clientes</span>
            </a>
        </nav>
    </aside>

    <!-- Contenido Principal -->
    <main class="admin-main-content" id="mainContent">
        <!-- Header -->
        <header class="admin-header">
            <div class="header-left">
                <button class="sidebar-toggle" id="sidebarToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <h1 class="page-title">Nuevo Cliente</h1>
            </div>
            <div class="header-right">
                <div class="user-profile">
                    <div class="profile-info">
                        <img src="https://via.placeholder.com/45" alt="Usuario" class="profile-image">
                        <div class="user-info">
                            <span class="user-name">Administrador</span>
                            <span class="user-role">Admin</span>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Contenido -->
        <div class="admin-content">
            <div class="content-header">
                <div class="card">
                    <div class="card-header">
                        <h2 class="section-title">Crear Nuevo Cliente</h2>
                        <div class="header-actions">
                            <a href="index.php" class="btn btn-secondary">
                                <i class="fas fa-arrow-left"></i>
                                Volver
                            </a>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if ($error): ?>
                            <div style="padding: 15px; background: #f8d7da; color: #721c24; border-radius: 8px; margin-bottom: 20px; border: 1px solid #f5c6cb;">
                                <i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?>
                            </div>
                        <?php endif; ?>
                        
                        <form method="POST" action="" class="form-container">
                            <div class="form-grid">
                                <div class="form-group full-width" style="display: flex; flex-direction: row; gap: 20px; align-items: flex-start;">
                                    <div style="flex: 1; display: flex; flex-direction: column; min-width: 0;">
                                        <label class="form-label" for="tipoDocumento">Tipo de Documento</label>
                                        <select 
                                            id="tipoDocumento" 
                                            name="tipoDocumento" 
                                            class="form-input"
                                        >
                                            <option value="DNI" <?php echo (isset($_POST['tipoDocumento']) && $_POST['tipoDocumento'] === 'RUC') ? '' : 'selected'; ?>>DNI</option>
                                            <option value="RUC" <?php echo (isset($_POST['tipoDocumento']) && $_POST['tipoDocumento'] === 'RUC') ? 'selected' : ''; ?>>RUC</option>
                                        </select>
                                    </div>
                                    <div style="flex: 1; display: flex; flex-direction: column; min-width: 0;">
                                        <label class="form-label" for="dni" id="labelDocumento">DNI</label>
                                        <div style="display: flex; gap: 10px; align-items: flex-start;">
                                            <input 
                                                type="text" 
                                                id="dni" 
                                                name="dni" 
                                                class="form-input" 
                                                value="<?php echo htmlspecialchars($_POST['dni'] ?? ''); ?>"
                                                maxlength="11"
                                                pattern="[0-9]{8,11}"
                                                placeholder="Ingrese el documento"
                                                title="El documento debe tener 8 dígitos (DNI) o 11 dígitos (RUC)"
                                                style="flex: 1; min-width: 0;"
                                            >
                                            <button 
                                                type="button" 
                                                id="btnBuscarDocumento"
                                                class="btn btn-secondary"
                                                style="white-space: nowrap; padding: 10px 20px; flex-shrink: 0;"
                                                onclick="buscarPorDocumento()"
                                            >
                                                <i class="fas fa-search"></i>
                                                Buscar
                                            </button>
                                        </div>
                                        <small style="color: #6c757d; font-size: 0.85rem; margin-top: 5px; display: block;" id="helpDocumento">
                                            Solo números, 8 dígitos para DNI
                                        </small>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label" for="nombre">Nombre <span style="color: #dc3545;">*</span></label>
                                    <input 
                                        type="text" 
                                        id="nombre" 
                                        name="nombre" 
                                        class="form-input" 
                                        value="<?php echo htmlspecialchars($_POST['nombre'] ?? ''); ?>"
                                        required
                                        placeholder="Ingrese el nombre"
                                    >
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label" for="apellido">Apellido</label>
                                    <input 
                                        type="text" 
                                        id="apellido" 
                                        name="apellido" 
                                        class="form-input" 
                                        value="<?php echo htmlspecialchars($_POST['apellido'] ?? ''); ?>"
                                        placeholder="Ingrese el apellido"
                                    >
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label" for="email">Email <span style="color: #dc3545;">*</span></label>
                                    <input 
                                        type="email" 
                                        id="email" 
                                        name="email" 
                                        class="form-input" 
                                        value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                                        required
                                        placeholder="ejemplo@email.com"
                                    >
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label" for="telefono">Teléfono</label>
                                    <input 
                                        type="tel" 
                                        id="telefono" 
                                        name="telefono" 
                                        class="form-input" 
                                        value="<?php echo htmlspecialchars($_POST['telefono'] ?? ''); ?>"
                                        placeholder="Ingrese el teléfono"
                                    >
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label" for="fechaNacimiento">Fecha de Nacimiento</label>
                                    <input 
                                        type="date" 
                                        id="fechaNacimiento" 
                                        name="fechaNacimiento" 
                                        class="form-input" 
                                        value="<?php echo htmlspecialchars($_POST['fechaNacimiento'] ?? ''); ?>"
                                    >
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label" for="nacionalidad">Nacionalidad</label>
                                    <input 
                                        type="text" 
                                        id="nacionalidad" 
                                        name="nacionalidad" 
                                        class="form-input" 
                                        value="<?php echo htmlspecialchars($_POST['nacionalidad'] ?? ''); ?>"
                                        placeholder="Ej: Peruano"
                                    >
                                </div>
                                
                                <div class="form-group full-width">
                                    <label class="form-label" for="preferenciasViaje">Preferencias de Viaje</label>
                                    <textarea 
                                        id="preferenciasViaje" 
                                        name="preferenciasViaje" 
                                        class="form-input" 
                                        rows="3"
                                        placeholder="Ej: Aventura, cultura y gastronomía"
                                    ><?php echo htmlspecialchars($_POST['preferenciasViaje'] ?? ''); ?></textarea>
                                </div>
                            </div>
                            
                            <div class="form-actions">
                                <button type="submit" name="crear" class="btn btn-primary">
                                    <i class="fas fa-save"></i>
                                    Guardar Cliente
                                </button>
                                <a href="index.php" class="btn btn-secondary">
                                    <i class="fas fa-times"></i>
                                    Cancelar
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Contenedor para alertas -->
    <div id="alertasContainer"></div>

    <!-- JavaScript -->
    <script>
        // Toggle sidebar en móviles
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        const mainContent = document.getElementById('mainContent');

        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', function() {
                sidebar.classList.toggle('sidebar-collapsed');
                mainContent.classList.toggle('content-expanded');
            });
        }

        // Cerrar sidebar al hacer clic fuera en móviles
        document.addEventListener('click', function(event) {
            if (window.innerWidth <= 1024) {
                if (!sidebar.contains(event.target) && !sidebarToggle.contains(event.target)) {
                    sidebar.classList.remove('sidebar-collapsed');
                    mainContent.classList.remove('content-expanded');
                }
            }
        });

        // Función para mostrar alertas
        function mostrarAlerta(tipo, mensaje, duracion = 5000) {
            const alertasContainer = document.getElementById('alertasContainer');
            
            if (!alertasContainer) {
                const container = document.createElement('div');
                container.id = 'alertasContainer';
                document.body.appendChild(container);
            }
            
            const alerta = document.createElement('div');
            alerta.className = `alerta alerta-${tipo}`;
            
            const iconos = {
                success: '<i class="fas fa-check-circle"></i>',
                error: '<i class="fas fa-exclamation-circle"></i>',
                warning: '<i class="fas fa-exclamation-triangle"></i>',
                info: '<i class="fas fa-info-circle"></i>'
            };
            
            alerta.innerHTML = `
                <div style="display: flex; align-items: center; gap: 10px;">
                    ${iconos[tipo] || ''}
                    <span>${mensaje}</span>
                </div>
                <button class="cerrar-alerta" onclick="this.parentElement.remove()">
                    <i class="fas fa-times"></i>
                </button>
            `;
            
            alertasContainer.appendChild(alerta);
            
            setTimeout(() => {
                alerta.style.opacity = '1';
                alerta.style.transform = 'translateY(0)';
            }, 10);
            
            setTimeout(() => {
                alerta.style.opacity = '0';
                alerta.style.transform = 'translateY(-100%)';
                setTimeout(() => {
                    if (alerta.parentNode) {
                        alerta.remove();
                    }
                }, 300);
            }, duracion);
        }

        // Exportar función globalmente
        window.mostrarAlerta = mostrarAlerta;
        
        // Función para actualizar el campo de documento según el tipo seleccionado
        function actualizarCampoDocumento() {
            const tipoDocumento = document.getElementById('tipoDocumento');
            const dniInput = document.getElementById('dni');
            const labelDocumento = document.getElementById('labelDocumento');
            const helpDocumento = document.getElementById('helpDocumento');
            
            if (tipoDocumento && dniInput && labelDocumento && helpDocumento) {
                const tipo = tipoDocumento.value;
                
                if (tipo === 'RUC') {
                    labelDocumento.textContent = 'RUC';
                    dniInput.maxLength = 11;
                    dniInput.pattern = '[0-9]{11}';
                    dniInput.placeholder = 'Ingrese 11 dígitos';
                    helpDocumento.textContent = 'Solo números, 11 dígitos para RUC';
                } else {
                    labelDocumento.textContent = 'DNI';
                    dniInput.maxLength = 8;
                    dniInput.pattern = '[0-9]{8}';
                    dniInput.placeholder = 'Ingrese 8 dígitos';
                    helpDocumento.textContent = 'Solo números, 8 dígitos para DNI';
                }
                
                // Limpiar el campo al cambiar de tipo
                dniInput.value = '';
            }
        }
        
        // Función para buscar por documento
        function buscarPorDocumento() {
            const tipoDocumento = document.getElementById('tipoDocumento').value;
            const documento = document.getElementById('dni').value;
            
            if (!documento) {
                mostrarAlerta('warning', 'Por favor ingrese un ' + tipoDocumento + ' para buscar');
                return;
            }
            
            // Validar longitud según el tipo
            const longitudEsperada = tipoDocumento === 'RUC' ? 11 : 8;
            if (documento.length !== longitudEsperada) {
                mostrarAlerta('warning', 'El ' + tipoDocumento + ' debe tener exactamente ' + longitudEsperada + ' dígitos');
                return;
            }
            
            // Deshabilitar el botón mientras se busca
            const btnBuscar = document.getElementById('btnBuscarDocumento');
            const btnOriginalText = btnBuscar.innerHTML;
            btnBuscar.disabled = true;
            btnBuscar.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Buscando...';
            
            // Mostrar mensaje de búsqueda
            mostrarAlerta('info', 'Buscando información del ' + tipoDocumento + '...');
            
            // Realizar petición AJAX
            const urlBusqueda = 'CLIENTES/buscar_cliente.php?tipo=' + encodeURIComponent(tipoDocumento) + '&documento=' + encodeURIComponent(documento) + '&debug=1';
            console.log('🔍 Realizando búsqueda:', urlBusqueda);
            
            fetch(urlBusqueda)
                .then(response => {
                    console.log('📥 Respuesta recibida - Status:', response.status);
                    if (!response.ok) {
                        return response.text().then(text => {
                            console.error('❌ Error HTTP:', text);
                            throw new Error('HTTP error! status: ' + response.status);
                        });
                    }
                    return response.json();
                })
                .then(data => {
                    // Restaurar el botón
                    btnBuscar.disabled = false;
                    btnBuscar.innerHTML = btnOriginalText;
                    
                    console.log('📋 Respuesta completa:', JSON.stringify(data, null, 2)); // Debug completo
                    
                    if (data.success) {
                        // Llenar los campos del formulario con los datos encontrados
                        if (data.datos) {
                            console.log('✅ Datos recibidos:', data.datos);
                            
                            let camposLlenados = 0;
                            
                            // Para DNI: separar nombre y apellidos
                            if (tipoDocumento === 'DNI') {
                                const nombreField = document.getElementById('nombre');
                                const apellidoField = document.getElementById('apellido');
                                
                                console.log('🔎 Buscando campos en DOM...');
                                console.log('  - Campo nombre:', nombreField ? '✓ encontrado' : '✗ NO encontrado');
                                console.log('  - Campo apellido:', apellidoField ? '✓ encontrado' : '✗ NO encontrado');
                                
                                if (nombreField) {
                                    if (data.datos.nombre && data.datos.nombre.trim()) {
                                        nombreField.value = data.datos.nombre.trim();
                                        camposLlenados++;
                                        console.log('✓ Nombre asignado:', data.datos.nombre);
                                    } else {
                                        console.warn('⚠ Nombre vacío o no disponible');
                                    }
                                } else {
                                    console.error('✗ Campo nombre no encontrado en el DOM');
                                }
                                
                                if (apellidoField) {
                                    if (data.datos.apellido && data.datos.apellido.trim()) {
                                        apellidoField.value = data.datos.apellido.trim();
                                        camposLlenados++;
                                        console.log('✓ Apellido asignado:', data.datos.apellido);
                                    } else if ((data.datos.apellidoPaterno && data.datos.apellidoPaterno.trim()) || 
                                               (data.datos.apellidoMaterno && data.datos.apellidoMaterno.trim())) {
                                        const apellidos = [
                                            data.datos.apellidoPaterno || '',
                                            data.datos.apellidoMaterno || ''
                                        ].filter(a => a && a.trim()).join(' ').trim();
                                        if (apellidos) {
                                            apellidoField.value = apellidos;
                                            camposLlenados++;
                                            console.log('✓ Apellidos combinados:', apellidos);
                                        }
                                    } else {
                                        console.warn('⚠ Apellido vacío o no disponible');
                                        console.log('📋 Todos los campos disponibles en data.datos:', Object.keys(data.datos));
                                        console.log('📋 Valores de campos relacionados con apellidos:');
                                        console.log('  - apellido:', data.datos.apellido);
                                        console.log('  - apellidos:', data.datos.apellidos);
                                        console.log('  - apellidoPaterno:', data.datos.apellidoPaterno);
                                        console.log('  - apellidoMaterno:', data.datos.apellidoMaterno);
                                        if (data.debug && data.debug.camposDisponibles) {
                                            console.log('📋 Campos disponibles en la respuesta de la API:', data.debug.camposDisponibles);
                                        }
                                    }
                                } else {
                                    console.error('✗ Campo apellido no encontrado en el DOM');
                                }
                            } else {
                                // Para RUC: el nombre completo va en el campo nombre
                                const nombreField = document.getElementById('nombre');
                                console.log('🔎 Buscando campo nombre (RUC):', nombreField ? '✓ encontrado' : '✗ NO encontrado');
                                console.log('📋 Datos recibidos para RUC:', data.datos);
                                
                                if (nombreField) {
                                    // Intentar múltiples campos posibles que la API puede devolver
                                    const nombreCompleto = (
                                        data.datos.nombre || 
                                        data.datos.nombreCompleto || 
                                        data.datos.razonSocial ||
                                        data.datos.denominacion ||
                                        ''
                                    ).trim();
                                    
                                    if (nombreCompleto) {
                                        nombreField.value = nombreCompleto;
                                        camposLlenados++;
                                        console.log('✓ Nombre RUC asignado:', nombreCompleto);
                                    } else {
                                        console.warn('⚠ Nombre RUC vacío o no disponible');
                                        console.log('📋 Todos los campos disponibles en data.datos:', Object.keys(data.datos));
                                        if (data.debug && data.debug.camposDisponibles) {
                                            console.log('📋 Campos disponibles en la respuesta de la API:', data.debug.camposDisponibles);
                                        }
                                        if (data.debug && data.debug.rawResponse) {
                                            console.log('🔍 Respuesta cruda de la API:', data.debug.rawResponse);
                                        }
                                    }
                                } else {
                                    console.error('✗ Campo nombre no encontrado en el DOM');
                                }
                            }
                            
                            console.log(`📊 Total de campos llenados: ${camposLlenados}`);
                            
                            if (camposLlenados === 0) {
                                console.warn('⚠ Ningún campo fue llenado. Verificar estructura de datos.');
                                if (data.debug && data.debug.rawResponse) {
                                    console.log('🔍 Respuesta cruda de la API:', data.debug.rawResponse);
                                }
                            }
                        } else {
                            console.warn('⚠ No se recibieron datos en la respuesta');
                            console.log('Estructura completa de data:', data);
                        }
                        
                        mostrarAlerta('success', 'Información del ' + tipoDocumento + ' encontrada y cargada');
                    } else {
                        console.error('❌ Búsqueda fallida:', data.message);
                        mostrarAlerta('error', data.message || 'No se encontró información para el ' + tipoDocumento);
                    }
                })
                .catch(error => {
                    // Restaurar el botón
                    btnBuscar.disabled = false;
                    btnBuscar.innerHTML = btnOriginalText;
                    
                    console.error('❌ Error al buscar:', error);
                    mostrarAlerta('error', 'Error al buscar el ' + tipoDocumento + '. Por favor intente nuevamente.');
                });
        }
        
        // Event listener para el cambio de tipo de documento
        const tipoDocumentoSelect = document.getElementById('tipoDocumento');
        if (tipoDocumentoSelect) {
            tipoDocumentoSelect.addEventListener('change', actualizarCampoDocumento);
        }
        
        // Validación del documento en tiempo real
        const dniInput = document.getElementById('dni');
        if (dniInput) {
            dniInput.addEventListener('input', function(e) {
                // Solo permitir números
                this.value = this.value.replace(/[^0-9]/g, '');
                
                // Limitar según el tipo de documento
                const tipoDocumento = document.getElementById('tipoDocumento').value;
                const maxLength = tipoDocumento === 'RUC' ? 11 : 8;
                
                if (this.value.length > maxLength) {
                    this.value = this.value.slice(0, maxLength);
                }
            });
            
            dniInput.addEventListener('blur', function(e) {
                // Validar al salir del campo
                const tipoDocumento = document.getElementById('tipoDocumento').value;
                const longitudEsperada = tipoDocumento === 'RUC' ? 11 : 8;
                
                if (this.value.length > 0 && this.value.length !== longitudEsperada) {
                    mostrarAlerta('warning', 'El ' + tipoDocumento + ' debe tener exactamente ' + longitudEsperada + ' dígitos');
                    this.focus();
                }
            });
        }
        
        // Validación del formulario antes de enviar
        const form = document.querySelector('form');
        if (form) {
            form.addEventListener('submit', function(e) {
                const tipoDocumento = document.getElementById('tipoDocumento').value;
                const documento = document.getElementById('dni').value;
                const longitudEsperada = tipoDocumento === 'RUC' ? 11 : 8;
                
                if (documento && documento.length !== longitudEsperada) {
                    e.preventDefault();
                    mostrarAlerta('error', 'El ' + tipoDocumento + ' debe tener exactamente ' + longitudEsperada + ' dígitos');
                    document.getElementById('dni').focus();
                    return false;
                }
            });
        }
        
        // Mostrar alerta de error si existe
        <?php if ($error): ?>
            mostrarAlerta('error', '<?php echo addslashes($error); ?>');
        <?php endif; ?>
    </script>
</body>
</html>

